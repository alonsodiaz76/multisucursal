SET foreign_key_checks = 0;
#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ae7fbe2fe432f9db206d353622b716aa7f1e492', '2806:370:8260:a50f:e541:6c6e:d961:961', 1676046688, '__ci_last_regenerate|i:1676046681;currency|s:1:\"$\";currency_placement|s:4:\"Left\";currency_code|s:0:\"\";view_date|s:10:\"dd-mm-yyyy\";view_time|s:2:\"12\";inv_username|s:5:\"admin\";inv_userid|s:1:\"1\";logged_in|b:1;role_id|s:1:\"1\";role_name|s:5:\"Admin\";success|s:15:\"Welcome Admin !\";__ci_vars|a:1:{s:7:\"success\";s:3:\"old\";}language|s:7:\"Spanish\";language_id|s:1:\"7\";');


#
# TABLE STRUCTURE FOR: db_brands
#

DROP TABLE IF EXISTS `db_brands`;

CREATE TABLE `db_brands` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `brand_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (1, 'CT0001', 'Continental', 'Continental Tire For All-Season Performanceâ€”Find a New Road Forward. 100+ Years Of Excellence', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (2, 'CT0002', 'Harris', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (3, 'CT0003', 'UniChem', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (4, 'CT0004', 'Sacato', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (5, 'CT0005', 'Black &amp; Decker', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (6, 'CT0006', 'Pyroil', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (7, 'CT0007', 'Golden Supreme', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (8, 'CT0008', 'Permatex', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (9, 'CT0009', 'Cristal', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (10, 'CT0010', 'Mechanics Brand', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (11, 'CT0011', 'Lucas Oil Products', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (12, 'CT0012', 'BlueDevil', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (13, 'CT0013', 'Foset', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (14, 'CT0014', 'SK2.000', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (15, 'CT0015', 'Gunk', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (16, 'CT0016', 'Rislone', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (17, 'CT0017', 'CRC', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (18, 'CT0018', 'Amsoil', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (19, 'CT0019', 'Pretul', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (20, 'CT0020', 'Truper', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (21, 'CT0021', 'Dap', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (22, 'CT0022', 'Stanley', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (23, 'CT0023', '3M', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (24, 'CT0024', 'Wix', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (25, 'CT0025', 'Penzoil', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (26, 'CT0026', 'Valvoline', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (27, 'CT0027', 'Xcel', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (28, 'CT0028', 'DuraPower', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (29, 'CT0029', 'Interstate Batteries', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (30, 'CT0030', 'K29', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (31, 'CT0031', 'GreatNeck', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (32, 'CT0032', 'California Scent', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (33, 'CT0033', 'Exotica Fresheners', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (34, 'CT0034', 'ET Accesorios', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (35, 'CT0035', 'ASI Chemical', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (36, 'CT0036', 'Power Eagle', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (37, 'CT0037', 'OEM Industrial', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (38, 'CT0038', 'Master Lock', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (39, 'CT0039', 'Fiero', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (40, 'CT0040', 'Eastman Tools', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (41, 'CT0041', 'Panasonic', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (42, 'CT0042', 'Purolator', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (43, 'CT0043', 'Brava', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (44, 'CT0044', 'NGK', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (45, 'CT0045', 'Angel Guard', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (46, 'CT0046', 'Armorall', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (47, 'CT0047', 'Rain X', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (48, 'CT0048', 'STP', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (49, 'CT0049', 'Supercool', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (50, 'CT0050', 'AC PRO', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (51, 'CT0051', 'JB-Weld', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (52, 'CT0052', 'DMX', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (53, 'CT0053', 'Chispas', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (54, 'CT0054', 'formula 1', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (55, 'CT0055', 'Motor Trent', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (56, 'CT0056', 'ECO Lighting', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (57, 'CT0057', 'Protol', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (58, 'CT0058', 'Firestone', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (59, 'CT0059', 'Good year', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (60, 'CT0060', 'Bridgestone', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (61, 'CT0061', 'Thunderer', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (62, 'CT0062', 'Volteck', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (63, 'CT0063', 'Nelson Melendez', 'herramientas', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (64, 'CT0064', 'Valley', 'herramientas', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (65, 'CT0065', 'Elmer&#039;s', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (66, 'CT0066', 'white dog', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (67, 'CT0067', 'Lion Ball', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (68, 'CT0068', 'Brak', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (69, 'CT0069', 'wd40', '', NULL, 1);


#
# TABLE STRUCTURE FOR: db_category
#

DROP TABLE IF EXISTS `db_category`;

CREATE TABLE `db_category` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `category_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (6, 'CT0001', 'Accesorios', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (7, 'CT0007', 'Aditivos', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (8, 'CT0008', 'Brillo', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (9, 'CT0009', 'Ferreteria', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (10, 'CT0010', 'Gomas', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (11, 'CT0011', 'Herramientas', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (12, 'CT0012', 'Plomeria', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (13, 'CT0013', 'Desinfectantes', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (14, 'CT0014', 'Pinturas', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (15, 'CT0015', 'Electricidad', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (16, 'CT0016', 'Jardineria', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (17, 'CT0017', 'Baterias', '', NULL, 1);


#
# TABLE STRUCTURE FOR: db_cobpayments
#

DROP TABLE IF EXISTS `db_cobpayments`;

CREATE TABLE `db_cobpayments` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `customer_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,2) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_company
#

DROP TABLE IF EXISTS `db_company`;

CREATE TABLE `db_company` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `company_code` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_website` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_logo` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upi_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upi_code` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gst_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vat_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pan_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_details` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cid` int(10) DEFAULT NULL,
  `category_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INITAL CODE',
  `supplier_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INITAL CODE',
  `purchase_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INITAL CODE',
  `purchase_return_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INITAL CODE',
  `sales_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INITAL CODE',
  `sales_return_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_view` int(5) DEFAULT NULL COMMENT '1=Standard,2=Indian GST',
  `status` int(1) DEFAULT NULL,
  `sms_status` int(1) DEFAULT NULL COMMENT '1=Enable 0=Disable',
  `sales_terms_and_conditions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_company` (`id`, `company_code`, `company_name`, `company_website`, `mobile`, `phone`, `email`, `website`, `company_logo`, `logo`, `upi_id`, `upi_code`, `country`, `state`, `city`, `address`, `postcode`, `gst_no`, `vat_no`, `pan_no`, `bank_details`, `cid`, `category_init`, `item_init`, `supplier_init`, `purchase_init`, `purchase_return_init`, `customer_init`, `sales_init`, `sales_return_init`, `expense_init`, `invoice_view`, `status`, `sms_status`, `sales_terms_and_conditions`) VALUES (1, '', 'Multisucursal', NULL, '573504931577', '', 'admin@latamcodev.com', '', 'ico_(2).png', 'logo-0.png', '', 'Copia_de_Universidad.png', 'Perú', 'PR', 'Lima', 'Carretera 119 Km 78.3', '00683', '', '66-0925908', '', '', 1, 'CT', 'IT', 'SP', 'PU', 'PR', 'CU', 'SL', 'PR', 'EX', 1, 1, 0, '');


#
# TABLE STRUCTURE FOR: db_country
#

DROP TABLE IF EXISTS `db_country`;

CREATE TABLE `db_country` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(4050) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `added_on` date DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_country` (`id`, `country_code`, `country`, `added_on`, `company_id`, `status`) VALUES (2, NULL, 'USA', NULL, NULL, 1);
INSERT INTO `db_country` (`id`, `country_code`, `country`, `added_on`, `company_id`, `status`) VALUES (3, NULL, 'Puerto Rico', NULL, NULL, 1);
INSERT INTO `db_country` (`id`, `country_code`, `country`, `added_on`, `company_id`, `status`) VALUES (4, NULL, 'Perú', NULL, NULL, 1);
INSERT INTO `db_country` (`id`, `country_code`, `country`, `added_on`, `company_id`, `status`) VALUES (5, NULL, 'honduras', NULL, NULL, 1);


#
# TABLE STRUCTURE FOR: db_currency
#

DROP TABLE IF EXISTS `db_currency`;

CREATE TABLE `db_currency` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` blob DEFAULT NULL,
  `symbol` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_currency` (`id`, `currency_name`, `currency_code`, `currency`, `symbol`, `status`) VALUES (56, 'Dolar Americano', '', '$', NULL, 1);


#
# TABLE STRUCTURE FOR: db_customer_payments
#

DROP TABLE IF EXISTS `db_customer_payments`;

CREATE TABLE `db_customer_payments` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `salespayment_id` int(5) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `payment` double(20,2) DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_date` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `salespayment_id` (`salespayment_id`),
  CONSTRAINT `db_customer_payments_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `db_customer_payments_ibfk_2` FOREIGN KEY (`salespayment_id`) REFERENCES `db_salespayments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=457 DEFAULT CHARSET=utf8mb4;

INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (199, 5, 4, '2022-02-11', 'ATH Movil', '4.18', '', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '08:14:09', '2022-02-11', 'justiniano', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (200, 24, 4, '2022-12-08', 'Cash', '2.65', 'Paid By Cash', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '01:59:02', '2022-12-08', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (271, 20, 3, '2022-12-07', 'Cash', '2.51', '', '190.166.7.28', '28.7.166.190.f.sta.codetel.net.do', '05:22:52', '2022-12-07', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (272, 28, 3, '2022-12-26', 'Cash', '1.62', 'Paid By Cash', '186.151.122.214', '186.151.122.214', '05:20:26', '2022-12-26', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (305, 14, 2, '2022-11-04', 'Cash', '1581.06', 'Paid By Cash', '190.239.152.159', '190.239.152.159', '05:03:25', '2022-11-04', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (306, 17, 2, '2022-11-11', 'Cash', '21.90', 'Paid By Cash', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '11:53:32', '2022-11-11', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (307, 18, 2, '2022-11-11', 'Cash', '21.90', '', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '11:53:59', '2022-11-11', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (308, 26, 2, '2022-12-21', 'Cash', '6.49', 'Paid By Cash', '190.110.45.6', 'corp-190-110-45-6.punto.net.ec', '10:29:45', '2022-12-21', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (309, 30, 2, '2022-12-27', 'Cash', '11.00', 'ewe', '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', '04:29:53', '2022-12-27', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (426, 3, 1, '2022-02-03', 'Cash', '3.00', '', '107.72.164.16', '107.72.164.16', '09:22:01', '2022-02-03', 'justiniano', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (427, 4, 1, '2022-02-09', 'Cash', '19.78', '', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '09:33:31', '2022-02-09', 'justiniano', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (428, 6, 1, '2022-02-17', 'Cash', '15.43', '', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '11:56:25', '2022-02-17', 'justiniano', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (429, 7, 1, '2022-02-17', 'Cash', '93.66', 'Paid By Cash', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '12:51:48', '2022-02-17', 'justiniano', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (430, 8, 1, '2022-06-06', 'Cash', '6.54', 'Paid By Cash', '186.85.71.135', 'static-ip-1868571135.cable.net.co', '01:04:21', '2022-06-06', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (431, 9, 1, '2022-06-06', 'Cash', '107.69', '', '45.229.41.216', '45.229.41.216', '09:20:17', '2022-06-06', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (432, 10, 1, '2022-08-27', 'Cash', '52.26', 'Paid By Cash', '190.149.71.206', '190.149.71.206', '12:21:45', '2022-08-27', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (433, 11, 1, '2022-08-27', 'Cash', '9.83', 'fernadno', '190.149.71.206', '190.149.71.206', '12:23:16', '2022-08-27', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (434, 12, 1, '2022-10-01', 'Cash', '1.62', '', '102.223.24.178', '102.223.24.178', '09:59:12', '2022-10-01', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (435, 13, 1, '2022-10-16', 'Cash', '43.44', '', '190.14.141.2', '190.14.141.2', '07:35:45', '2022-10-16', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (436, 15, 1, '2022-11-11', 'Cash', '21.90', 'Paid By Cash', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '11:53:23', '2022-11-11', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (437, 16, 1, '2022-11-11', 'Cash', '21.90', 'Paid By Cash', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '11:53:28', '2022-11-11', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (438, 19, 1, '2022-12-07', 'Cash', '120.83', 'Paid By Cash', '181.211.10.26', '26.10.211.181.static.anycast.cnt-grms.ec', '03:24:22', '2022-12-07', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (439, 21, 1, '2022-12-08', 'Cash', '7.27', '', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '01:26:09', '2022-12-08', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (440, 22, 1, '2022-12-08', 'Cash', '42.00', 'Paid By Cash', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '01:38:01', '2022-12-08', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (441, 23, 1, '2022-12-08', 'Cash', '9.96', '', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '01:49:55', '2022-12-08', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (442, 25, 1, '2022-12-19', 'Cash', '31.05', 'Paid By Cash', '2800:200:f488:99bb:d0e4:d2ed:4301:fe87', '2800:200:f488:99bb:d0e4:d2ed:4301:fe87', '11:16:36', '2022-12-19', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (443, 27, 1, '2022-12-24', 'Cash', '6.63', 'Paid By Cash', '190.237.88.234', '190.237.88.234', '01:26:33', '2022-12-24', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (444, 29, 1, '2022-12-27', 'Cash', '1.62', 'Paid By Cash', '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', '04:28:13', '2022-12-27', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (445, 31, 1, '2023-01-26', 'Cash', '77.60', '', '186.32.100.2', '186.32.100.2', '10:43:52', '2023-01-26', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (446, 32, 1, '2023-01-26', 'Cash', '115.00', '', '186.32.100.2', '186.32.100.2', '10:51:58', '2023-01-26', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (447, 33, 1, '2023-01-29', 'Cash', '5.00', 'Paid By Cash', '190.83.61.27', '190.83.61.27', '04:22:07', '2023-01-29', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (448, 34, 1, '2023-02-01', 'Cash', '5.00', '', '187.154.236.133', 'dsl-187-154-236-133-dyn.prod-infinitum.com.mx', '06:31:05', '2023-02-01', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (449, 35, 1, '2023-02-08', 'Cash', '18.00', 'Paid By Cash', '45.191.88.207', '45.191.88.207', '08:27:02', '2023-02-08', 'admin', 1);


#
# TABLE STRUCTURE FOR: db_customers
#

DROP TABLE IF EXISTS `db_customers`;

CREATE TABLE `db_customers` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `customer_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gstin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vatin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opening_balance` double(20,2) DEFAULT NULL,
  `sales_due` double(20,2) DEFAULT NULL,
  `sales_return_due` double(20,2) DEFAULT NULL,
  `country_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (1, 'CU0001', 'Walk-in customer', '', '', '', '', '', NULL, NULL, '0.00', '0.00', '', '', NULL, '', '', NULL, NULL, '2019-01-01', '10:55:54 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (2, 'CU0002', 'carlos irizarry', NULL, '', NULL, '', '', NULL, '0.00', '0.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-02-03', '10:04:30 am', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (3, 'CU0003', 'Ramon Rodriguez', NULL, '', '', '', '', NULL, '0.00', '0.00', NULL, NULL, NULL, NULL, '', '', NULL, NULL, '2022-02-09', '08:28:14 am', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (4, 'CU0004', 'Yamilette Gonzalez', NULL, '', '', '', '', NULL, '0.00', '0.00', NULL, NULL, NULL, '', NULL, '', NULL, NULL, '2022-02-11', '08:12:52 am', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (5, 'CU0005', 'Municipio San German', '', '', '', '', '', NULL, '0.00', '0.00', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, '2022-02-11', '08:58:11 am', 'admin', NULL, 1);


#
# TABLE STRUCTURE FOR: db_expense
#

DROP TABLE IF EXISTS `db_expense`;

CREATE TABLE `db_expense` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `expense_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(5) DEFAULT NULL,
  `expense_date` date DEFAULT NULL,
  `reference_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_for` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_amt` double(20,2) DEFAULT NULL,
  `note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_expense_category
#

DROP TABLE IF EXISTS `db_expense_category`;

CREATE TABLE `db_expense_category` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `category_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_hold
#

DROP TABLE IF EXISTS `db_hold`;

CREATE TABLE `db_hold` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `reference_id` varchar(50) DEFAULT NULL,
  `reference_no` varchar(50) DEFAULT NULL,
  `sales_date` date DEFAULT NULL,
  `sales_status` varchar(50) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,2) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,2) DEFAULT NULL,
  `discount_to_all_input` double(20,2) DEFAULT NULL,
  `discount_to_all_type` varchar(50) DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,2) DEFAULT NULL,
  `subtotal` double(20,2) DEFAULT NULL,
  `round_off` double(20,2) DEFAULT NULL,
  `grand_total` double(20,2) DEFAULT NULL,
  `sales_note` text DEFAULT NULL,
  `pos` int(1) DEFAULT NULL COMMENT '1=yes 0=no',
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `db_hold_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: db_holditems
#

DROP TABLE IF EXISTS `db_holditems`;

CREATE TABLE `db_holditems` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `hold_id` int(5) DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_qty` double(20,2) DEFAULT NULL,
  `price_per_unit` double(20,2) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,2) DEFAULT NULL,
  `discount_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_input` double(20,2) DEFAULT NULL,
  `discount_amt` double(20,2) DEFAULT NULL,
  `unit_total_cost` double(20,2) DEFAULT NULL,
  `total_cost` double(20,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_id` (`hold_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `db_holditems_ibfk_2` FOREIGN KEY (`hold_id`) REFERENCES `db_hold` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `db_holditems_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `db_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_items
#

DROP TABLE IF EXISTS `db_items`;

CREATE TABLE `db_items` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_barcode` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(10) DEFAULT NULL,
  `sku` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hsn` varbinary(50) DEFAULT NULL,
  `unit_id` int(10) DEFAULT NULL,
  `alert_qty` int(10) DEFAULT NULL,
  `brand_id` int(5) DEFAULT NULL,
  `lot_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `price` double(20,2) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `purchase_price` double(20,2) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profit_margin` double(20,2) DEFAULT NULL,
  `sales_price` double(20,2) DEFAULT NULL,
  `final_price` double(20,2) DEFAULT NULL,
  `stock` double(20,2) DEFAULT NULL,
  `item_image` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `discount_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` double(20,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (1, 'IT0001', '820909082200', '3 Led Cap Light With Batteries', '', 6, '8220', '', 17, 1, 0, '', NULL, '0.75', 4, '0.84', 'Exclusive', '73.00', '1.45', '1.62', '0.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (2, 'IT0002', '826942654893', '4pc Heavy Duty Car &amp; Truck Mats Motor Trend', NULL, 6, 'MT-921-BK', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '29.95', '33.09', '0.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (3, 'IT0003', '731015000142', 'Bl8nd Spot Mirror Round', NULL, 6, 'CA086', '', 17, 0, NULL, '', NULL, '1.25', 1, '1.38', 'Exclusive', NULL, '2.95', '3.26', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (4, 'IT0004', '070158000030', 'Krazy Glue All Purpose Super Glue', NULL, 6, 'KG58348MR', '', 17, 0, NULL, '', NULL, '0.99', 1, '1.09', 'Exclusive', NULL, '1.65', '1.82', '10.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (5, 'IT0005', '078727442090', '4 Minute Epoxy Steel', NULL, 7, '44209', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '4.45', '4.92', '-3.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (6, 'IT0006', '078727431094', '5 Minutes Epoxy Adhesive', NULL, 7, '43109', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '4.45', '4.92', '3.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (7, 'IT0007', '043425313195', 'J-B Weld Black Silicone RTV', NULL, 7, '31319', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '3.45', '3.81', '-3.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (8, 'IT0008', '043425313102', 'J-B Weld Clear Silicone ', NULL, 7, '31310', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '3.45', '3.81', '2.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (9, 'IT0009', '043425323279', 'J-B Weld Ultimate Grey Gasket Maker &amp; Sealant', '', 7, '32327', '', 17, 1, 51, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '3.45', '3.81', '0.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (10, 'IT0010', '672264024087', 'Leak Stop R-134a A/C System', '', 7, '24087', '', 17, 1, 49, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '5.95', '6.57', '8.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (11, 'IT0011', '048168452514', 'PAG 100 Oil Charge R-134A With ICE 32', '', 7, '765-3139', '', 17, 1, 50, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '5.95', '6.57', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (12, 'IT0012', '078727275698', 'Prime Lok Stud &amp; Bearing Red 275', NULL, 7, '27569', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '3.25', '3.59', '11.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (13, 'IT0013', '048168049264', 'R-12 To R-134a Retrofit Parts Kit', NULL, 7, '765-3144', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '12.95', '14.31', '2.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (14, 'IT0014', '048168025213', 'R-134a Recharge Hose Adapter Standard To Self Sealing', NULL, 7, '765-3152', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '3.95', '4.36', '3.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (15, 'IT0015', '686226818447', 'Rearview Mirror Adhesive', NULL, 7, '765-1184', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '3.45', '3.81', '11.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (16, 'IT0016', '048168053070', 'Refrigerant 134a With Stop Leak ', NULL, 7, 'Id1902', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '8.95', '9.89', '5.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (17, 'IT0017', '080319000168', 'Refrigerant R-134a', NULL, 7, 'GHS 012R134a', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '6.95', '7.68', '11.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (18, 'IT0018', '078727999396', 'VersaChem Mega Grey Silicone Gasket Maker ', NULL, 7, '99939', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '3.95', '4.36', '5.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (19, 'IT0019', '897444000280', 'M-16 Flowshine All In 1 Cherry Scent', NULL, 8, '', '', 17, 0, NULL, '', NULL, '4.23', 1, '4.67', 'Exclusive', NULL, '5.95', '6.57', '11.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (20, 'IT0020', '078175051004', 'Mag &amp; Aluminum Polish', NULL, 8, '05100', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '8.45', '9.34', '4.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (21, 'IT0021', '811656004409', 'Metal &amp; Aluminum Polish Angel Guatd', NULL, 8, 'ANG 440', '', 17, 0, NULL, '', NULL, '2.49', 1, '2.75', 'Exclusive', NULL, '3.95', '4.36', '10.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (22, 'IT0022', '897444000327', 'Mr. Wash &amp; Wax  Multi-Cleaner Uvita ', NULL, 8, '', '', 17, 0, NULL, '', NULL, '2.40', 1, '2.65', 'Exclusive', NULL, '3.95', '4.36', '83.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (23, 'IT0023', '071099138110', 'Scratch Out FÃ³rmula 1 Swirl Remover', NULL, 8, '653644', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '4.95', '5.47', '11.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (24, 'IT0024', '013948260184', 'Harris Chromall', '', 14, 'chromall', '', 17, 1, 2, '', NULL, '3.25', 4, '3.62', 'Exclusive', '37.00', '4.95', '5.52', '5.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (25, 'IT0025', '013948250154', 'Harris Paint &amp; Primer 2X dark blue', '', 14, 'dark blue', '', 17, 1, 2, '', NULL, '2.35', 4, '2.62', 'Exclusive', '28.00', '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (26, 'IT0026', '013948250024', 'Harris Paint &amp; Primer 2X Flat White', '', 14, 'flat white', '', 17, 1, 2, '', NULL, '2.35', 4, '2.62', 'Exclusive', '28.00', '3.35', '3.74', '5.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (27, 'IT0027', '013948250253', 'Harris Paint &amp; Primer 2X Walnut', '', 14, 'walnut', '', 17, 1, 2, '', NULL, '2.35', 4, '2.62', 'Exclusive', '28.00', '3.35', '3.74', '3.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (28, 'IT0028', '013948250000', 'Harris Paint &amp; Primer 2X Clear Acrylic', '', 14, 'clear acrylic', '', 17, 1, 2, '', NULL, '2.35', 4, '2.62', 'Exclusive', '28.00', '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (29, 'IT0029', '013948250017', 'Harris Paint &amp; Primer 2X Gloss White', '', 14, 'gloss white', '', 17, 0, 2, ' ', NULL, '2.35', 4, '2.62', 'Exclusive', '28.00', '3.35', '3.74', '5.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (30, 'IT0030', '013948250086', 'Harris Paint &amp; Primer 2X  Gray Primer', '', 14, 'FCP.80 gray primer', '', 17, 1, 2, '', NULL, '2.35', 4, '2.62', 'Exclusive', '28.00', '3.35', '3.74', '5.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (31, 'IT0031', '013948250147', 'Harris Paint &amp; Primer 2X Red Primer', '', 14, 'fcp.80 red primer', '', 17, 1, 2, '', NULL, '2.35', 4, '2.62', 'Exclusive', '28.00', '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (32, 'IT0032', '013948250208', 'Harris Paint &amp; Primer 2X Yellow', '', 14, 'NFP .95 Yellow', '', 17, 1, 2, '', NULL, '2.35', 4, '2.62', 'Exclusive', '28.00', '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (33, 'IT0033', '013948250109', 'Harris Paint &amp; Primer 2X Copper', '', 14, 'NFP .95 Copper', '', 17, 1, 2, '', NULL, '2.35', 4, '2.62', 'Exclusive', '28.00', '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (34, 'IT0034', '013948250055', 'Harris Paint &amp; Primer 2X Dark Green', '', 14, 'NFP .95 Dark green', '', 17, 1, 2, '', NULL, '2.35', 4, '2.62', 'Exclusive', '28.00', '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (35, 'IT0035', '013948250307', 'Harris Paint &amp; Primer 2X Beige', '', 14, 'NFP.95 beige', '', 17, 1, 2, '', NULL, '2.45', 4, '2.73', 'Exclusive', '23.00', '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (36, 'IT0036', '013948260252', 'Engine Enamel Harris Recond Flat Black', '', 14, '1.20 Recond Flat Black', '', 17, 1, 2, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (37, 'IT0037', '013948260160', 'Engine enamel Harris Cast Iron Grey', '', 14, 'FCP.80 Cast iron Grey', '', 17, 1, 2, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '3.35', '3.74', '5.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (38, 'IT0038', '013948260009', 'Engine Enamel Harris Univ Black', '', 14, 'NFP 1.40 Univ Black', '', 17, 1, 2, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '3.35', '3.74', '3.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (39, 'IT0039', '013948260221', 'Engine Enamel Harris Universal Gray', '', 14, 'NFP .95 Universal Grey', '', 17, 1, 2, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (40, 'IT0040', '013948260399', 'Engine Enamel Harris Gold E/E', '', 14, 'NFP .95 Gold', '', 17, 1, 2, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '3.35', '3.74', '5.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (41, 'IT0041', '013948260177', 'Engine Enamel Harris Hi-Temp Aluminum', '', 14, 'HTC 1.85 Aluminum', '', 17, 1, 2, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (42, 'IT0042', '013948260030', 'Engine Enamel Harris Chevy Orange', '', 14, 'NFP .95 Chevy Orange', '', 17, 1, 2, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (43, 'IT0043', '013948260016', 'Engine Enamel Harris Ford Red', '', 14, 'NFP .95 Ford Red', '', 17, 2, 2, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '3.35', '3.74', '5.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (44, 'IT0044', '013948260054', 'Engine Enamel Harris Ford Blue', '', 14, 'NFP .95 Ford Blue', '', 17, 0, 2, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '3.35', '3.74', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (45, 'IT0045', '013948260146', 'Engine Enamel Harris Cater Yellow', '', 14, 'NFP .95  CATER YELLOW', '', 17, 0, 2, '', NULL, '0.00', 4, '0.00', 'Exclusive', NULL, '3.35', '3.74', '5.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (46, 'IT0046', '0', '235/35ZR20 92W XL SPORT NS1', NULL, 10, '', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '99.95', '110.44', '0.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (47, 'IT0047', '885911524643', 'B &amp; D High Pressure Washer 1450 Psi', '', 11, 'BW13-B3', '', 17, 1, 5, '', NULL, '65.95', 4, '73.53', 'Exclusive', '29.00', '94.95', '105.87', '1.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (48, 'IT0048', '7506240634577', 'Basin Stainless Steel Flexible Hose FLA-30XL', NULL, 12, '45488', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '2.95', '3.26', '6.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (49, 'IT0049', '7506240634584', 'Manguera Flexible De Acero Inoxidable FLA-40XL', NULL, 12, '45489', '', 17, 0, NULL, '', NULL, '0.00', 1, '0.00', 'Exclusive', NULL, '3.75', '4.14', '2.00', NULL, '216.164.121.166', '216.164.121.166', '2022-02-02', '01:07:10 am', 'admin', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (50, 'IT0050', '098968400116', '70% Ethyl Alcohol UniChem 32oz', '70% Alcohol Ethyl  32 oz', 13, '', '', 17, 1, 3, '', NULL, '3.00', 4, '3.34', 'Exclusive', '48.00', '4.95', '5.52', '24.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '08:47:03 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (52, 'IT0052', '013948389038', 'Appliance Hard Epoxy Enamel Almond', '', 14, 'appliance almond', '', 17, 1, 2, '', NULL, '3.50', 4, '3.90', 'Exclusive', '27.00', '4.95', '5.52', '5.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '12:54:05 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (53, 'IT0053', '013948389014', 'Appliance Hard Epoxy Enamel White', '', 14, 'appliance White', '', 17, 1, 2, '', NULL, '3.50', 4, '3.90', 'Exclusive', '27.00', '4.95', '5.52', '5.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '12:58:04 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (54, 'IT0054', '815179020021', 'Brake Parts Cleaner', '', 7, 'py4003', '', 17, 1, 6, '', NULL, '2.39', 4, '2.66', 'Exclusive', '48.00', '3.95', '4.40', '10.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '01:38:16 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (55, 'IT0055', '718890007794', 'Carburetor &amp; Choke Cleaner', '', 7, 'che-121c', '', 17, 1, 7, '', NULL, '2.45', 4, '2.73', 'Exclusive', '37.00', '3.75', '4.18', '10.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '01:40:22 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (56, 'IT0056', '686226818331', 'Rubberized Undercoating', '', 7, '765-2644', '', 17, 0, 8, '', NULL, '3.25', 4, '3.62', 'Exclusive', '37.00', '4.95', '5.52', '5.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '01:43:11 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (57, 'IT0057', '018890145633', 'Brake Cleaner Cristal 14oz', '', 7, '', '', 17, 1, 9, '', NULL, '2.25', 4, '2.51', 'Exclusive', '51.00', '3.79', '4.23', '9.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '01:45:55 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (58, 'IT0058', '718890007978', 'Starting Fluid 11oz', '', 7, 'che-124-cs', '', 17, 1, 7, '', NULL, '2.25', 4, '2.51', 'Exclusive', '51.00', '3.79', '4.23', '8.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '01:48:06 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (59, 'IT0059', '076768115003', 'Tire Fixer Inflator &amp; Repair', '', 7, '51150mb', '', 17, 1, 10, '', NULL, '3.00', 4, '3.34', 'Exclusive', '27.00', '4.25', '4.74', '4.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '01:50:51 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (60, 'IT0060', '018890039017', 'Quick Fix Inflates &amp; Seals', '', 7, 'che-106-c', '', 17, 1, 7, '', NULL, '2.65', 4, '2.95', 'Exclusive', '44.00', '4.25', '4.74', '5.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '01:52:33 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (61, 'IT0061', '049807100094', 'Lucas Transmission Fix (24 oz.)', '', 7, '10009', '', 17, 1, 11, '', NULL, '8.50', 4, '9.48', 'Exclusive', '58.00', '14.99', '16.71', '2.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '01:57:59 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (62, 'IT0062', '091838002058', 'BlueDevil Radiator and Block Sealer', '', 7, '00205', '', 17, 0, 12, '', NULL, '15.00', 4, '16.73', 'Exclusive', '55.00', '25.99', '28.98', '3.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-04', '02:25:34 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (63, 'IT0063', '891838002362', 'Transmission Sealer Pour - N - Go', '', 7, '', '', 17, 0, 12, '', NULL, '14.00', 4, '15.61', 'Exclusive', '66.00', '25.95', '28.93', '2.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '07:32:14 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (64, 'IT0064', '717666106082', 'Super Kote 2.000 Tratamiento Motor', '', 7, '', '', 17, 1, 14, '', NULL, '18.00', 4, '20.07', 'Exclusive', '24.00', '24.95', '27.82', '7.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '08:18:04 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (65, 'IT0065', '078698131825', 'Oil Treatment Motor Medic', '', 7, 'm1815', '', 17, 1, 15, '', NULL, '3.00', 4, '3.34', 'Exclusive', '49.00', '4.99', '5.56', '9.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '08:21:12 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (66, 'IT0066', '078615041022', 'Engine Treatment Rislone 16.9oz', '', 7, '4102', '', 17, 1, 16, '', NULL, '4.00', 4, '4.46', 'Exclusive', '40.00', '6.25', '6.97', '6.00', 'uploads/items/1645111935.jpg', '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '08:23:47 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (67, 'IT0067', '078254061627', 'Fuel Stabilizer CRC', '', 7, 'crc#899a 14a', '', 17, 1, 17, '', NULL, '5.00', 4, '5.58', 'Exclusive', '34.00', '7.45', '8.31', '11.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '08:26:48 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (68, 'IT0068', '078254050638', 'Guaranteed To Pass', '', 7, 'crc#425f', '', 17, 1, 17, '', NULL, '12.99', 4, '14.48', 'Exclusive', '38.00', '19.99', '22.29', '1.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '08:29:19 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (69, 'IT0069', '810006220834', 'TransMedic Tratamiento Transmision', '', 7, 'm3616', '', 17, 1, 15, '', NULL, '3.25', 4, '3.62', 'Exclusive', '49.00', '4.99', '5.56', '10.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '08:31:30 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (70, 'IT0070', '097012308019', 'Engine &amp; Trasmission Flush Amsoil', '', 7, 'flshcn', '', 17, 1, 18, '', NULL, '6.00', 4, '6.69', 'Exclusive', '124.00', '14.99', '16.71', '1.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '09:04:08 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (71, 'IT0071', '097012043002', 'Power Foam Induction System Cleaner', '', 7, 'apf-sc', '', 17, 0, 18, '', NULL, '7.00', 4, '7.80', 'Exclusive', '92.00', '14.99', '16.71', '2.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '09:06:06 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (72, 'IT0072', '656489130006', 'Interstate Batteries D  pack of 2 Alkaline', '', 17, 'dry0020', '', 17, 1, 29, '', '2026-12-31', '1.99', 4, '2.22', 'Exclusive', '80.00', '3.99', '4.45', '12.00', 'uploads/items/1645190693.jpg', '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '09:08:38 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (73, 'IT0073', '656489129994', 'Interstate Batteries C  pack of 2 Alkaline', '', 17, 'dry0015', '', 17, 1, 29, '', '2026-12-31', '2.50', 4, '2.79', 'Exclusive', '43.00', '3.99', '4.45', '12.00', 'uploads/items/1645190653.jpg', '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '09:10:47 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (74, 'IT0074', '656489129963', 'Interstate Batteries 9V  Alkaline', '', 17, 'dry0005', '', 17, 1, 29, '', '2026-12-31', '1.99', 4, '2.22', 'Exclusive', '80.00', '3.99', '4.45', '12.00', 'uploads/items/1645190620.jpg', '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '09:13:18 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (75, 'IT0075', '811656004508', 'Headlight Lens Restorer', '', 8, 'ang-450', '', 17, 1, 45, '', NULL, '2.66', 4, '2.97', 'Exclusive', '68.00', '4.99', '5.56', '10.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '09:54:55 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (76, 'IT0076', '018890386067', 'Untouchable Wet Tire Finish', '', 8, '', '', 17, 0, 9, '', NULL, '3.00', 4, '3.34', 'Exclusive', '49.00', '4.99', '5.56', '2.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '09:56:59 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (77, 'IT0077', '718890008623', 'Untouchable Glass Cleaner', '', 8, 'cri-305-c', '', 17, 1, 9, '', NULL, '2.25', 4, '2.51', 'Exclusive', '59.00', '3.99', '4.45', '6.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '09:59:01 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (78, 'IT0078', '070612100108', 'Armorall Protectant 10oz', '', 8, '', '', 17, 1, 46, '', NULL, '3.00', 4, '3.34', 'Exclusive', '76.00', '5.89', '6.57', '12.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '10:00:58 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (79, 'IT0079', '071153003507', 'Tuff Stuff Multi - Purpose Foam Cleaner', '', 8, '11-12007', '', 17, 1, 48, '', NULL, '1.95', 4, '2.17', 'Exclusive', '107.00', '4.49', '5.01', '6.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '10:03:44 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (80, 'IT0080', '018890038638', 'GX-3 Plastic Restorer', '', 8, 'cri-113-c', '', 17, 1, 9, '', NULL, '2.89', 4, '3.22', 'Exclusive', '55.00', '4.99', '5.56', '20.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '10:06:39 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (81, 'IT0081', '846351079933', 'Performance Octane Booster', '', 7, '79933', '', 17, 1, 43, '', NULL, '1.50', 4, '1.67', 'Exclusive', '137.00', '3.95', '4.40', '6.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '10:09:46 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (82, 'IT0082', '846351079926', 'Fuel Injector Cleaner', '', 7, '79926', '', 17, 1, 43, '', NULL, '1.50', 4, '1.67', 'Exclusive', '137.00', '3.95', '4.40', '6.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '10:11:01 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (83, 'IT0083', '846351079902', 'Super Gas Treatment', '', 7, '79902', '', 17, 1, 43, '', NULL, '1.50', 4, '1.67', 'Exclusive', '137.00', '3.95', '4.40', '8.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '10:32:51 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (84, 'IT0084', '846351079919', 'High Mileage Fuel Treatment', '', 7, '79919', '', 17, 1, 43, '', NULL, '1.50', 4, '1.67', 'Exclusive', '137.00', '3.95', '4.40', '8.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '10:34:34 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (85, 'IT0085', '815179020052', 'Fuel injector Cleaner Pyroil', '', 7, 'pyafl12p', '', 17, 1, 6, '', NULL, '1.89', 4, '2.11', 'Exclusive', '87.00', '3.95', '4.40', '8.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '10:36:32 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (86, 'IT0086', '810006220063', 'Fuel Injection System Treatment Motor Medic', '', 7, 'm5212', '', 17, 1, 15, '', NULL, '2.25', 4, '2.51', 'Exclusive', '59.00', '3.99', '4.45', '4.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '10:39:28 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (87, 'IT0087', '074130790773', 'Water Remover Valvoline', '', 7, '602247', '', 17, 1, 26, '', NULL, '2.25', 4, '2.51', 'Exclusive', '59.00', '3.99', '4.45', '7.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '10:41:44 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (88, 'IT0088', '079118010645', 'Rain X 7oz', '', 8, '0611', '', 17, 1, 47, '', NULL, '3.15', 4, '3.51', 'Exclusive', '42.00', '4.99', '5.56', '11.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '10:57:36 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (89, 'IT0089', '811656001309', 'Wet Look Cristalizer Angel Guard', '', 8, 'ang-130', '', 17, 1, 45, '', NULL, '4.95', 4, '5.52', 'Exclusive', '40.00', '7.73', '8.62', '7.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '11:01:02 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (90, 'IT0090', '811656006663', 'Engine Shine &amp; Protectant', '', 8, 'ang-666', '', 17, 1, 45, '', NULL, '4.50', 4, '5.02', 'Exclusive', '40.00', '7.03', '7.84', '10.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '11:04:20 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (91, 'IT0091', '013948386051', 'Ever Black Plastic Restorer', '', 8, '', '', 17, 1, 2, '', NULL, '3.50', 4, '3.90', 'Exclusive', '54.00', '5.99', '6.68', '7.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '12:27:57 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (92, 'IT0092', '013948386044', 'Ever Wet Tire Shine', '', 8, '', '', 17, 1, 2, '', NULL, '3.50', 4, '3.90', 'Exclusive', '54.00', '5.99', '6.68', '23.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '12:30:13 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (93, 'IT0093', '079118959739', '2 in 1 Glass Cleaner + Rain Repellent', '', 8, '1112', '', 17, 1, 47, '', NULL, '3.50', 4, '3.90', 'Exclusive', '54.00', '5.99', '6.68', '2.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '12:32:31 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (94, 'IT0094', '713283231282', 'ASI Carpet &amp; Upholstery Cleaner', '', 8, '', '', 17, 1, 35, '', NULL, '5.00', 4, '5.58', 'Exclusive', '79.00', '9.99', '11.14', '1.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '12:36:21 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (95, 'IT0095', '713283230162', 'ASI Vinyl &amp; Leather Conditioner', '', 8, '', '', 17, 1, 35, '', NULL, '5.00', 4, '5.58', 'Exclusive', '79.00', '9.99', '11.14', '3.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '12:38:03 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (96, 'IT0096', '713283270328', 'ASI Rubber &amp; Trim', '', 8, '', '', 17, 1, 35, '', NULL, '7.50', 4, '8.36', 'Exclusive', '79.00', '14.99', '16.71', '5.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '12:39:26 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (97, 'IT0097', '713283221283', 'ASI Car Wash Soap PH Balanceado', '', 8, '', '', 17, 1, 35, '', NULL, '5.00', 4, '5.58', 'Exclusive', '79.00', '9.99', '11.14', '5.00', NULL, '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '12:40:52 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (98, 'IT0098', '656489130020', 'Interstate Batteries AA paquete 4 Alkaline', '', 17, 'dry0030', '', 17, 1, 29, '', '2026-12-31', '1.99', 4, '2.22', 'Exclusive', '80.00', '3.99', '4.45', '7.00', 'uploads/items/1645190589.jpg', '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '12:43:55 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (99, 'IT0099', '656489130051', 'Interstate Batteries AAA  pack of 4 Alkaline', '', 17, 'dry0035', '', 17, 1, 29, '', '2026-12-31', '1.99', 4, '2.22', 'Exclusive', '80.00', '3.99', '4.45', '3.00', 'uploads/items/1645190535.jpg', '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '12:46:20 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (100, 'IT0100', '656489302427', 'Interstate Batteries AAA  pack of 24 Alkaline', '', 17, 'dry0191', '', 17, 1, 29, '', '2026-12-31', '7.50', 4, '8.36', 'Exclusive', '79.00', '14.99', '16.71', '3.00', 'uploads/items/1645188787.jpg', '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '12:48:57 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (101, 'IT0101', '656489302410', 'Interstate Batteries AA  pack of 24 Alkaline', 'Interstate Batteries AA  pack of 24 Alkaline', 17, 'dry0190', '', 17, 1, 29, '', '2026-12-31', '7.50', 4, '8.36', 'Exclusive', '79.00', '14.99', '16.71', '2.00', 'uploads/items/1645188696.jpg', '107.77.216.81', 'mobile-107-77-216-81.mobile.att.net', '2022-02-05', '12:50:37 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (102, 'IT0102', '018890000321', 'Visible Glass Cleaner 32oz', '', 8, '', '', 17, 1, 9, '', NULL, '1.25', 4, '1.39', 'Exclusive', '43.00', '1.99', '2.22', '8.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-07', '12:49:13 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (103, 'IT0103', '018890040013', 'Wash &amp; Wax Cristal 16oz', '', 8, '', '', 17, 1, 9, '', NULL, '1.75', 4, '1.95', 'Exclusive', '53.00', '2.99', '3.33', '4.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-07', '12:50:46 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (104, 'IT0104', '811656003334', 'Car Wash 16 oz', '', 8, 'ang-333', '', 17, 1, 45, '', NULL, '1.75', 4, '1.95', 'Exclusive', '53.00', '2.99', '3.33', '12.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-07', '12:52:28 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (105, 'IT0105', 'cocat5nr', 'Carretilla 5.5ft3, mangos madera,llanta neumÃ¡tica 16&quot;', 'Llanta neumÃ¡tica reforzada con rin de 3 aspas\r\nConcha de lÃ¡mina calibre 23 (0.68 mm)\r\nBastidores cuadrados de madera (41 x 41 mm)\r\nPuente que brinda mayor estabilidad\r\nCapacidad (Copeteada / Ras) 5.5 ftÂ³ (156 L) / 2.8 ftÂ³ (80 L)\r\nMedidas de la concha 27&quot; (69 cm) x 36 1/2&quot; (93 cm) x 11&quot; (28 cm)\r\nMedidas de llanta 16&quot; (41 cm) x 4&quot; (10 cm)\r\nResistencia de carga 350 kg\r\nPuente con doble tornillo Calibre 19 (1 mm)\r\nSoporte y tacÃ³n Calibre 16 (1.5 mm)', 9, '20622', 'CAP-5WNDR', 17, 1, 19, '', NULL, '64.95', 4, '72.42', 'Exclusive', '24.00', '89.95', '100.29', '2.00', 'uploads/items/1644930709.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '11:12:43 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (106, 'IT0106', '7501206600115', 'Wire Wheel Brush 1 1/2 diametro', '', 9, '11573', '', 17, 1, 20, '', NULL, '1.76', 4, '1.96', 'Exclusive', '40.00', '2.75', '3.07', '3.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '11:19:49 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (107, 'IT0107', '7501206675670', 'Wire Wheel Brush 2&quot; diametro', '', 9, '11569', '', 17, 1, 20, '', NULL, '1.55', 4, '1.73', 'Exclusive', '59.00', '2.75', '3.07', '1.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '11:24:07 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (108, 'IT0108', '7501206643655', 'Wire Wheel Set for Drills', '', 9, '11577', '', 17, 1, 20, '', NULL, '10.91', 4, '12.16', 'Exclusive', '39.00', '16.95', '18.90', '2.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '11:26:16 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (109, 'IT0109', '7501206600160', 'Wire Wheel Brush 4&quot; diametro', '', 9, '11590', '', 17, 1, 20, '', NULL, '3.54', 4, '3.95', 'Exclusive', '41.00', '5.55', '6.19', '3.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '11:29:17 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (110, 'IT0110', '7501206600139', 'Wire Wheel Brush 3&quot; diametro', '', 9, '11575', '', 17, 1, 20, '', NULL, '2.72', 4, '3.03', 'Exclusive', '40.00', '4.25', '4.74', '3.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '11:32:08 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (111, 'IT0111', '7501206600184', 'Wire Wheel Cup Brush 2&quot; 3/4 diametro', '', 9, '11592', '', 17, 1, 20, '', NULL, '4.07', 4, '4.54', 'Exclusive', '40.00', '6.35', '7.08', '3.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '11:34:51 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (112, 'IT0112', '704300960223', 'DMX Wash &amp; Wax 16oz', '', 8, '', '', 17, 1, 52, '', NULL, '1.50', 4, '1.67', 'Exclusive', '79.00', '2.99', '3.33', '10.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '12:39:36 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (113, 'IT0113', '704300960216', 'DMX Wash &amp; Wax 64oz', '', 8, '', '', 17, 1, 52, '', NULL, '2.50', 4, '2.79', 'Exclusive', '115.00', '5.99', '6.68', '5.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '12:41:33 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (114, 'IT0114', '7506240600183', 'Regulador para Gas una via', '', 9, '49225', '', 17, 1, 13, '', NULL, '7.51', 4, '8.37', 'Exclusive', '43.00', '11.95', '13.32', '4.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '12:43:39 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (115, 'IT0115', '7501206635124', 'Pistola calafateadora lisa, Pretul Caulk Gun', 'Pistola calafateadora lisa, Pretul\r\nCuerpo de acero\r\n', 9, '22800', 'PICA-9L', 17, 1, 19, '', NULL, '2.72', 4, '3.03', 'Exclusive', '40.00', '4.25', '4.74', '5.00', 'uploads/items/1644933454.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '12:45:59 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (116, 'IT0116', '7506240672531', 'Revolvedor Cemento y Lechada', '', 9, '11975', '', 17, 1, 20, '', NULL, '6.99', 4, '7.79', 'Exclusive', '41.00', '10.95', '12.21', '2.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '12:48:06 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (117, 'IT0117', '7501206643211', 'Remachadora 10&quot; Pretul', '', 9, '22850', '', 17, 1, 19, '', NULL, '4.99', 4, '5.56', 'Exclusive', '79.00', '9.95', '11.09', '3.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '12:50:32 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (118, 'IT0118', '7501206603543', 'Cautin 30W Pretul', '', 9, '22805', '', 17, 1, 19, '', NULL, '6.97', 4, '7.77', 'Exclusive', '40.00', '10.85', '12.10', '3.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '12:52:13 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (119, 'IT0119', '7501206698143', 'Manguera Flexible para Gas', '', 9, '49136', '', 17, 1, 13, '', NULL, '5.31', 4, '5.92', 'Exclusive', '51.00', '8.95', '9.98', '6.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '12:54:46 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (120, 'IT0120', '7501206618646', 'Llavero tipo Bandola', 'Fabricados en aluminio\r\nTipo bandola\r\nColores surtidos', 9, '65002', '', 17, 1, 19, '', NULL, '0.68', 4, '0.76', 'Exclusive', '64.00', '1.25', '1.39', '27.00', 'uploads/items/1644609147.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '12:58:38 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (121, 'IT0121', '075650000311', 'Touch &#039;n Foam Max 3x Fill', '', 9, '2919006', '', 17, 1, 21, '', NULL, '5.35', 4, '5.97', 'Exclusive', '42.00', '8.45', '9.42', '12.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '01:41:05 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (122, 'IT0122', '7706912650366', 'Machete Chispas 14.5&quot;  #1820 Cabo Madera', '', 9, '1102076', '#1820', 17, 1, 53, '', NULL, '5.05', 4, '5.63', 'Exclusive', '77.00', '9.95', '11.09', '7.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '02:45:34 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (123, 'IT0123', '', 'Tornillo Acoplar Tanque 5/16 x 3&quot;', '', 9, '380015-sip', '0129020', 17, 1, 0, '', NULL, '1.03', 4, '1.15', 'Exclusive', '61.00', '1.85', '2.06', '10.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '03:32:51 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (124, 'IT0124', '', 'Tornillo Inodoro piso 1/4 x 2 1/4', '', 9, 'EB28', '0129021', 17, 1, 0, '', NULL, '0.47', 4, '0.52', 'Exclusive', '44.00', '0.75', '0.84', '10.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '03:34:45 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (125, 'IT0125', '074130790759', 'Fuel Injector Cleaner Valvoline', '', 7, '602378', '', 17, 1, 26, '', NULL, '2.28', 4, '2.54', 'Exclusive', '48.00', '3.75', '4.18', '12.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-09', '03:49:27 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (126, 'IT0126', '', 'Lampara de Emergencia Led', '', 9, 'Skem-7012', '3199806A', 17, 1, 56, '', NULL, '20.95', 4, '23.36', 'Exclusive', '41.00', '32.95', '36.74', '3.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '08:17:53 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (127, 'IT0127', '0657559717677', 'Led Lightbulb 12w /100w', 'Lifetime 40.000h\r\n6500 K ( Pure White )\r\nBright 1600', 9, '60-enled-12w', '3104162C', 17, 1, 57, '', NULL, '2.92', 4, '3.26', 'Exclusive', '43.00', '4.65', '5.18', '12.00', 'uploads/items/1644609736.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '08:21:38 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (128, 'IT0128', '0657559685877', 'Led Lightbulb 9w /75w', 'Lifetime 40.000h\r\n6500 K ( Pure White )\r\nBright 1300', 9, '60-enled-9w', '3104162b', 17, 1, 57, '', NULL, '2.67', 4, '2.98', 'Exclusive', '43.00', '4.25', '4.74', '12.00', 'uploads/items/1644609702.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '08:32:34 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (129, 'IT0129', '', 'EFFICIENTGRIP PERF - 215/55R16 Good Year', '', 10, 'GY 109708', '', 17, 1, 59, '', NULL, '83.23', 4, '92.80', 'Exclusive', '15.00', '106.72', '118.99', '7.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '09:01:06 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (130, 'IT0130', '', 'Alenza A/S 02 - 275/50R22 Bridgestone', '', 10, 'BR 007157', '', 17, 1, 60, '', NULL, '245.00', 4, '273.18', 'Exclusive', '10.00', '300.50', '335.06', '7.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '09:02:49 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (131, 'IT0131', '', 'DUELER A/T REVO 2 - 245/65R17', '', 10, 'BR 14946005', '', 17, 1, 60, '', NULL, '129.00', 4, '143.84', 'Exclusive', '10.00', '158.22', '176.42', '4.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '09:04:12 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (132, 'IT0132', '', 'Thunderer Ranger R402 - 195/75R16C', '', 10, 'TH TH0412', '', 17, 1, 61, '', NULL, '87.40', 4, '97.45', 'Exclusive', '20.00', '116.94', '130.39', '7.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '09:05:24 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (133, 'IT0133', '', 'Transforce CV - 235/65R16C', '', 10, 'FIR 004709', '', 17, 1, 58, '', NULL, '132.00', 4, '147.18', 'Exclusive', '10.00', '161.90', '180.52', '7.00', NULL, '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '09:06:47 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (134, 'IT0134', '7501206693902', 'Nudo para Cable 3/8', 'Fabricados en hierro maleable, acabado galvanizado\r\nPara conexiones de cables donde no se pueden usar terminales ni prensarse\r\nPara uniones temporales', 9, '44086', '', 17, 1, 39, '', NULL, '1.02', 4, '1.14', 'Exclusive', '75.00', '1.99', '2.22', '6.00', 'uploads/items/1644609063.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '12:10:46 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (135, 'IT0135', '', 'Cable Rigido 1/8 recubierto pvc 7x7', 'Fabricados de acero con acabado galvanizado\r\nRecubrimiento de PVC que evita maltratos a productos que se fijan o aseguran con el cable', 9, '44219', '', 19, 1, 39, '', NULL, '0.16', 4, '0.18', 'Exclusive', '67.00', '0.30', '0.33', '246.00', 'uploads/items/1644609002.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '12:15:37 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (136, 'IT0136', '7501206693865', 'Nudo para Cable 1/8 (2 piezas)', 'Fabricados en hierro maleable, acabado galvanizado\r\nPara conexiones de cables donde no se pueden usar terminales ni prensarse\r\nPara uniones temporales', 9, '44082', '', 17, 1, 39, '', NULL, '0.62', 4, '0.69', 'Exclusive', '116.00', '1.49', '1.66', '12.00', 'uploads/items/1644608469.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '12:17:50 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (137, 'IT0137', '7501206693872', 'Nudo para Cable 3/16 (2 piezas)', 'Fabricados en hierro maleable, acabado galvanizado\r\nPara conexiones de cables donde no se pueden usar terminales ni prensarse\r\nPara uniones temporales', 9, '44083', '', 17, 1, 39, '', NULL, '0.81', 4, '0.90', 'Exclusive', '99.00', '1.79', '2.00', '12.00', 'uploads/items/1644608443.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '12:54:26 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (138, 'IT0138', '7501206693889', 'Nudo para Cable 1/4 (2 piezas)', 'Fabricados en hierro maleable, acabado galvanizado\r\nPara conexiones de cables donde no se pueden usar terminales ni prensarse\r\nPara uniones temporales', 9, '44084', '', 17, 1, 39, '', NULL, '1.16', 4, '1.29', 'Exclusive', '93.00', '2.49', '2.78', '12.00', 'uploads/items/1644608416.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '12:55:44 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (139, 'IT0139', '7501206693896', 'Nudo para Cable 5/16 (2 piezas)', 'Fabricados en hierro maleable, acabado galvanizado\r\nPara conexiones de cables donde no se pueden usar terminales ni prensarse\r\nPara uniones temporales', 9, '44085', '', 17, 1, 39, '', NULL, '1.23', 4, '1.37', 'Exclusive', '82.00', '2.49', '2.78', '12.00', 'uploads/items/1644608384.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '12:57:42 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (140, 'IT0140', '750120663919', 'Nudo para Cable 1/2', 'Fabricados en hierro maleable, acabado galvanizado\r\nPara conexiones de cables donde no se pueden usar terminales ni prensarse\r\nPara uniones temporales', 9, '44087', '', 17, 1, 39, '', NULL, '1.36', 4, '1.52', 'Exclusive', '64.00', '2.49', '2.78', '6.00', 'uploads/items/1644608360.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '12:59:32 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (141, 'IT0141', '7501206694633', 'Tensor Gancho 3/16', 'Cuerpo metÃ¡lico\r\nArgolla y gancho fabricados en acero, acabado galvanizado\r\nPara tensar o emparejar cables', 9, '44053', '', 17, 1, 39, '', NULL, '1.34', 4, '1.49', 'Exclusive', '67.00', '2.49', '2.78', '6.00', 'uploads/items/1644607842.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '01:02:13 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (142, 'IT0142', '7501206694794', 'Tensor Gancho 1/4', 'Cuerpo metÃ¡lico\r\nArgolla y gancho fabricados en acero, acabado galvanizado\r\nPara tensar o emparejar cables', 9, '44054', '', 17, 1, 39, '', NULL, '1.83', 4, '2.04', 'Exclusive', '61.00', '3.29', '3.67', '6.00', 'uploads/items/1644607814.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '01:04:37 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (143, 'IT0143', '7501206694640', 'Tensor Gancho 5/16', 'Cuerpo metÃ¡lico\r\nArgolla y gancho fabricados en acero, acabado galvanizado\r\nPara tensar o emparejar cables', 9, '44055', '', 17, 1, 39, '', NULL, '2.44', 4, '2.72', 'Exclusive', '58.00', '4.29', '4.78', '6.00', 'uploads/items/1644607792.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '01:06:28 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (144, 'IT0144', '7501206694657', 'Tensor Gancho 3/8', 'Cuerpo metÃ¡lico\r\nArgolla y gancho fabricados en acero, acabado galvanizado\r\nPara tensar o emparejar cables', 9, '44056', '', 17, 1, 39, '', NULL, '2.74', 4, '3.06', 'Exclusive', '63.00', '4.99', '5.56', '6.00', 'uploads/items/1644607771.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '01:07:54 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (145, 'IT0145', '7501206694459', 'Bandola Destorcedor 7/16', 'Cuerpo metÃ¡lico\r\nOjo giratorio\r\nIdeales para sujetar cordones, correas para perros', 9, '44030', '', 17, 1, 39, '', NULL, '1.30', 4, '1.45', 'Exclusive', '55.00', '2.25', '2.51', '6.00', 'uploads/items/1644607634.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '01:13:26 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (146, 'IT0146', '7501206694473', 'Bandola Destorcedor 7/8', 'Cuerpo metÃ¡lico\r\nOjo giratorio\r\nIdeales para sujetar cordones, correas para perros', 9, '44032', '', 17, 1, 39, '', NULL, '2.04', 4, '2.27', 'Exclusive', '43.00', '3.25', '3.62', '6.00', 'uploads/items/1644607609.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '01:15:03 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (147, 'IT0147', '0657559804254', 'Pressure Switch 40-60 PSI', 'PRESSUE SWITCH 40-60 PSI\r\nâ€¢ For automatic operation or jet and submersible well pumps when used in conjunction with a diaphragm pressure tank or galvanized holding tank.\r\nâ€¢ The pressure of the switch you are replacing is shown inside the cap.\r\nâ€¢ Air pressure in tank must be set to 38 PSI', 12, 'pr-ps4060', '2020007', 17, 1, 57, '', NULL, '5.95', 4, '6.63', 'Exclusive', '276.00', '24.95', '27.82', '3.00', 'uploads/items/1644607255.jpg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '01:23:07 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (148, 'IT0148', '079118958558', 'Rain X 2 in 1 Glass Cleaner Trigguer 23oz', 'This Rain-X 2-In-1 Glass Cleaner is used on exterior and comes in 23 ounce spray bottle.', 8, '5071268', '', 17, 1, 47, '', NULL, '2.71', 4, '3.02', 'Exclusive', '74.00', '5.25', '5.85', '6.00', 'uploads/items/1644607117.jpeg', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '2022-02-11', '03:18:37 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (149, 'IT0149', '7501206658383', 'PortalÃ¡mpara de porcelana, 4-1/2&quot;, circular, Volteck', 'TensiÃ³n / Corriente: 120 V / 4 A\r\nCasquillo de aluminio\r\nDe sobreponer para fijar en pared o techo\r\nSoporta temperaturas elevadas (hasta 350 Â°C)', 9, '46524', 'popo-18', 17, 1, 62, '', NULL, '1.20', 4, '1.34', 'Exclusive', '46.00', '1.95', '2.17', '12.00', 'uploads/items/1644930527.jpg', '107.77.215.19', 'mobile-107-77-215-19.mobile.att.net', '2022-02-15', '09:08:47 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (150, 'IT0150', '', 'Cavador mango de madera 45&quot; Gemelas', 'Hojas de acero templado\r\nMangos redondos de madera\r\nLargo de mangos 45&quot; (114 cm)\r\nApertura mÃ¡xima 6&quot; (150 mm)\r\nEspesor de cabeza 1.8 mm', 9, '11973', 'CA-36', 17, 1, 20, '', NULL, '22.95', 4, '25.59', 'Exclusive', '37.00', '34.95', '38.97', '1.00', 'uploads/items/1644936693.jpg', '107.77.215.19', 'mobile-107-77-215-19.mobile.att.net', '2022-02-15', '10:51:33 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (151, 'IT0151', '', 'Cavador mango de acero 45&quot; Gemela', 'Hojas de acero templado\r\nMangos de acero con grips', 9, '11131', 'CA-36M', 17, 1, 20, '', NULL, '19.79', 4, '22.07', 'Exclusive', '36.00', '29.95', '33.39', '1.00', 'uploads/items/1644936885.jpg', '107.77.215.19', 'mobile-107-77-215-19.mobile.att.net', '2022-02-15', '10:54:45 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (152, 'IT0152', '7501206658345', 'PALA de corte ESCARRAMAN, MANGO LARGO', 'PALA ESCARRAMAN, MANGO LARGO', 9, '25022', 'pes-lrp', 17, 1, 19, '', NULL, '7.99', 4, '8.91', 'Exclusive', '45.00', '12.95', '14.44', '2.00', 'uploads/items/1644941805.png', '107.77.215.19', 'mobile-107-77-215-19.mobile.att.net', '2022-02-15', '12:16:45 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (153, 'IT0153', '7501206634387', 'Pala cuadrada mango largo, 56&quot;, Pretul', 'Mango largo fabricado en madera tropical con acabado encerado\r\nCabeza de acero al carbono con doble tratamiento tÃ©rmico y acabado en pintura epÃ³xica negra\r\nEnsamble: Interferencia y remache\r\nPara cavar o desplazar materiales de un sitio a otro\r\nModelo Pretul\r\nPuÃ±o Mango largo\r\nAncho de la cabeza (A) 9&quot; (23 cm)\r\nLargo de la cabeza (B) 19&quot; (48 cm)\r\nLargo total 56&quot; (142 cm)\r\nHombros Al frente\r\nAtado 3', 9, '22508', 'PCD-L', 17, 1, 19, '', NULL, '7.99', 4, '8.91', 'Exclusive', '45.00', '12.95', '14.44', '2.00', 'uploads/items/1644942228.jpg', '107.77.215.19', 'mobile-107-77-215-19.mobile.att.net', '2022-02-15', '12:23:48 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (154, 'IT0154', '7501206612026', 'AzadÃ³n Lane, No.2, mango 54&quot;, 2 lb', 'AzadÃ³n Lane, No.2, mango 54&quot;, 2 lb', 9, '10618', 'AL-2M', 17, 1, 20, '', NULL, '15.99', 4, '17.83', 'Exclusive', '40.00', '24.95', '27.82', '2.00', 'uploads/items/1644942582.jpg', '107.77.215.19', 'mobile-107-77-215-19.mobile.att.net', '2022-02-15', '12:29:42 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (155, 'IT0155', '7501206657782', 'Placa 2 modulos ABS, lÃ­nea standard', 'PPDO-S 2 34.1 mm x 28.5 mm DÃºplex\r\nColor Marfil\r\nDimensiones de la placa 114.0 mm x 69.6 mm\r\nEmpaque individual Bolsa', 9, '46406', 'ppdo-s', 17, 0, 62, '', NULL, '0.39', 4, '0.43', 'Exclusive', '40.00', '0.60', '0.67', '10.00', 'uploads/items/1644943476.jpg', '107.77.215.19', 'mobile-107-77-215-19.mobile.att.net', '2022-02-15', '12:44:36 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (156, 'IT0156', '7501206657836', 'Placa para interruptor vertical', 'Placa para interruptor vertical', 9, '46415', 'ppap-s', 17, 1, 62, '', NULL, '0.35', 4, '0.39', 'Exclusive', '54.00', '0.60', '0.67', '10.00', 'uploads/items/1645020009.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-16', '10:00:09 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (157, 'IT0157', '7501206657751', 'Placa Ciega ABS', 'Placa Ciega ABS', 9, '46400', 'ppci-s', 17, 1, 62, '', NULL, '0.39', 4, '0.43', 'Exclusive', '40.00', '0.60', '0.67', '10.00', 'uploads/items/1645020156.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-16', '10:02:36 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (158, 'IT0158', '7501206657843', 'Placa contacto redondo ABS, lÃ­nea standard', 'Placa contacto redondo ABS, lÃ­nea standard', 9, '46412', 'ppse-s', 17, 1, 62, '', NULL, '0.39', 4, '0.43', 'Exclusive', '40.00', '0.60', '0.67', '10.00', 'uploads/items/1645020291.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-16', '10:04:51 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (159, 'IT0159', '639469185005', 'Work Glove Leather / Canvas Large set', 'Work Glove Leather / Canvas Large set', 9, 'glove-001', '', 17, 1, 64, '', NULL, '2.25', 4, '2.51', 'Exclusive', '29.00', '3.25', '3.62', '12.00', 'uploads/items/1645029708.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-16', '12:41:48 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (160, 'IT0160', '026000070102', 'Wood Glue 8oz Elmer&#039;s', 'Wood Glue 8oz Elmer&#039;s', 9, 'E7010', '7010-11001us', 17, 1, 65, '', NULL, '1.69', 4, '1.69', 'Inclusive', '41.00', '2.65', '2.65', '10.00', 'uploads/items/1645033397.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-16', '01:43:17 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (161, 'IT0161', '639469020184', '18 pc Pneumatic Accessory Set 1/4 Brass', '18 pc Pneumatic Accessory Set 1/4 Brass', 9, 'ataha-18b', '', 17, 1, 64, '', NULL, '13.00', 4, '14.50', 'Exclusive', '38.00', '19.95', '22.24', '2.00', 'uploads/items/1645036217.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-16', '02:30:17 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (162, 'IT0162', '794685126406', '7pcs Insulated Screwdriver &amp; tester set', '7pcs Insulated Screwdriver &amp; tester set', 9, 'chis43007', '', 17, 1, 66, '', NULL, '13.00', 4, '14.50', 'Exclusive', '38.00', '19.95', '22.24', '1.00', 'uploads/items/1645038667.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-16', '03:11:07 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (163, 'IT0163', '', 'Lion Ball Loose Pin Hinges 3&quot;x3&quot;', 'Lion Ball Loose Pin Hinges 3&quot;x3&quot;', 9, '2275814457_PH-10269857876', '3007001', 17, 1, 67, '', NULL, '1.50', 4, '1.67', 'Exclusive', '41.00', '2.35', '2.62', '6.00', 'uploads/items/1645113931.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-17', '12:05:31 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (164, 'IT0164', '', 'Lion Ball Loose Pin Hinges 3 1/2 x 3 1/2', 'Lion Ball Loose Pin Hinges 3 1/2 x 3 1/2', 9, '3007002', '3007002', 17, 1, 67, '', NULL, '1.90', 4, '2.12', 'Exclusive', '39.00', '2.95', '3.29', '6.00', 'uploads/items/1645114135.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-17', '12:08:55 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (165, 'IT0165', '', 'Lion Ball Loose Pin Hinges 4x4', 'Lion Ball Loose Pin Hinges 4x4', 9, '3007005', '3007005', 17, 1, 67, '', NULL, '2.55', 4, '2.84', 'Exclusive', '39.00', '3.95', '4.40', '6.00', 'uploads/items/1645114323.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-17', '12:12:03 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (166, 'IT0166', '', 'Brak Rub Water Hose  50&#039; 5/8&quot;', '', 9, 'brk-50r', '', 17, 1, 68, '', NULL, '26.95', 4, '30.05', 'Exclusive', '40.00', '42.00', '46.83', '0.00', NULL, '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-17', '12:48:48 pm', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (167, 'IT0167', '656489162212', 'Interstate Batteries CR1620 watch', 'Interstate Batteries CR1620 watch', 9, 'lit0156', '', 17, 1, 29, '', '2024-07-31', '1.50', 4, '1.67', 'Exclusive', '35.00', '2.25', '2.51', '8.00', 'uploads/items/1645188481.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-18', '08:48:01 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (168, 'IT0168', '656489162519', 'Interstate Batteries CR2032  Alkaline', 'Interstate Batteries CR2032  Alkaline', 9, 'LIT0155', '', 17, 1, 29, '', '2031-12-31', '1.25', 5, '1.25', 'Exclusive', '62.00', '2.25', '2.51', '8.00', 'uploads/items/1645190920.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-18', '09:28:40 am', 'justiniano', NULL, 1, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (169, 'IT0169', '656489162502', 'Interstate Batteries CR2025  Alkaline', 'Interstate Batteries CR2025  Alkaline', 9, 'LIT0150', '', 17, 1, 29, '', '2031-12-31', '1.25', 4, '1.39', 'Exclusive', '62.00', '2.25', '2.51', '10.00', 'uploads/items/1645191041.jpg', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '2022-02-18', '09:30:41 am', 'justiniano', NULL, 0, 'Percentage', '0.00');
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`) VALUES (170, 'IT0170', '', 'PAÑALES HUGUIES 25', '', 6, 'sasas', 'asasas', 20, 100, 2, '144123325', '2023-01-03', '42.00', 2, '42.00', 'Inclusive', '25.00', '52.50', '52.50', '498.00', NULL, '200.37.203.118', '200.37.203.118', '2023-01-14', '07:53:33 am', 'admin', NULL, 1, 'Percentage', '0.00');


#
# TABLE STRUCTURE FOR: db_languages
#

DROP TABLE IF EXISTS `db_languages`;

CREATE TABLE `db_languages` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `language` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (1, 'English', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (2, 'Hindi', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (3, 'Kannada', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (4, 'Indonesian', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (5, 'Chinese', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (6, 'Russian', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (7, 'Spanish', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (8, 'Arabic', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (9, 'Albanian', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (10, 'Dutch', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (11, 'Bangla', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (12, 'Urdu', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (13, 'Italian', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (14, 'Marathi', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (15, 'Khmer', 1);


#
# TABLE STRUCTURE FOR: db_paymenttypes
#

DROP TABLE IF EXISTS `db_paymenttypes`;

CREATE TABLE `db_paymenttypes` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_paymenttypes` (`id`, `payment_type`, `status`) VALUES (1, 'Cash', 1);
INSERT INTO `db_paymenttypes` (`id`, `payment_type`, `status`) VALUES (2, 'Credit Card', 1);
INSERT INTO `db_paymenttypes` (`id`, `payment_type`, `status`) VALUES (5, 'ATH Movil', 1);
INSERT INTO `db_paymenttypes` (`id`, `payment_type`, `status`) VALUES (6, 'ATH', 1);
INSERT INTO `db_paymenttypes` (`id`, `payment_type`, `status`) VALUES (7, 'PayPal', 1);
INSERT INTO `db_paymenttypes` (`id`, `payment_type`, `status`) VALUES (8, 'On Account', 1);


#
# TABLE STRUCTURE FOR: db_permissions
#

DROP TABLE IF EXISTS `db_permissions`;

CREATE TABLE `db_permissions` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `role_id` int(5) DEFAULT NULL,
  `permissions` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=234 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (95, 2, 'users_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (96, 2, 'users_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (97, 2, 'users_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (98, 2, 'users_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (99, 2, 'tax_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (100, 2, 'tax_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (101, 2, 'tax_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (102, 2, 'tax_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (103, 2, 'currency_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (104, 2, 'currency_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (105, 2, 'currency_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (106, 2, 'currency_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (107, 2, 'company_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (108, 2, 'units_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (109, 2, 'units_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (110, 2, 'units_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (111, 2, 'units_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (112, 2, 'places_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (113, 2, 'places_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (114, 2, 'places_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (115, 2, 'places_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (116, 2, 'expense_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (117, 2, 'expense_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (118, 2, 'expense_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (119, 2, 'expense_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (120, 2, 'items_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (121, 2, 'items_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (122, 2, 'items_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (123, 2, 'items_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (124, 2, 'brand_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (125, 2, 'brand_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (126, 2, 'brand_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (127, 2, 'brand_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (128, 2, 'suppliers_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (129, 2, 'suppliers_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (130, 2, 'suppliers_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (131, 2, 'suppliers_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (132, 2, 'customers_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (133, 2, 'customers_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (134, 2, 'customers_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (135, 2, 'customers_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (136, 2, 'purchase_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (137, 2, 'purchase_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (138, 2, 'purchase_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (139, 2, 'purchase_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (140, 2, 'sales_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (141, 2, 'sales_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (142, 2, 'sales_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (143, 2, 'sales_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (144, 2, 'sales_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (145, 2, 'sales_payment_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (146, 2, 'sales_payment_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (147, 2, 'sales_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (148, 2, 'purchase_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (149, 2, 'expense_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (150, 2, 'profit_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (151, 2, 'stock_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (152, 2, 'item_sales_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (153, 2, 'purchase_payments_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (154, 2, 'sales_payments_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (155, 2, 'expired_items_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (156, 2, 'items_category_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (157, 2, 'items_category_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (158, 2, 'items_category_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (159, 2, 'items_category_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (160, 2, 'print_labels');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (161, 2, 'import_items');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (162, 2, 'expense_category_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (163, 2, 'expense_category_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (164, 2, 'expense_category_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (165, 2, 'expense_category_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (166, 2, 'dashboard_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (167, 2, 'purchase_return_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (168, 2, 'purchase_return_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (169, 2, 'purchase_return_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (170, 2, 'purchase_return_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (171, 2, 'purchase_return_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (172, 2, 'sales_return_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (173, 2, 'sales_return_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (174, 2, 'sales_return_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (175, 2, 'sales_return_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (176, 2, 'sales_return_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (177, 2, 'sales_return_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (178, 2, 'sales_return_payment_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (179, 2, 'sales_return_payment_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (180, 2, 'purchase_return_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (181, 2, 'purchase_return_payment_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (182, 2, 'purchase_return_payment_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (183, 2, 'purchase_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (184, 2, 'purchase_payment_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (185, 2, 'purchase_payment_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (186, 2, 'payment_types_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (187, 2, 'payment_types_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (188, 2, 'payment_types_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (189, 2, 'payment_types_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (190, 2, 'import_customers');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (191, 2, 'import_suppliers');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (192, 2, 'item_purchase_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (211, 3, 'places_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (212, 3, 'items_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (213, 3, 'brand_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (214, 3, 'customers_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (215, 3, 'customers_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (216, 3, 'purchase_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (217, 3, 'purchase_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (218, 3, 'sales_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (219, 3, 'sales_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (220, 3, 'sales_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (221, 3, 'sales_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (222, 3, 'sales_payment_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (223, 3, 'sales_payment_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (224, 3, 'items_category_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (225, 3, 'print_labels');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (226, 3, 'dashboard_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (227, 3, 'purchase_return_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (228, 3, 'sales_return_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (229, 3, 'sales_return_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (230, 3, 'sales_return_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (231, 3, 'purchase_return_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (232, 3, 'purchase_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (233, 3, 'purchase_payment_add');


#
# TABLE STRUCTURE FOR: db_purchase
#

DROP TABLE IF EXISTS `db_purchase`;

CREATE TABLE `db_purchase` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `purchase_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,2) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,2) DEFAULT NULL,
  `discount_to_all_input` double(20,2) DEFAULT NULL,
  `discount_to_all_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,2) DEFAULT NULL,
  `subtotal` double(20,2) DEFAULT NULL COMMENT 'Purchased qty',
  `round_off` double(20,2) DEFAULT NULL COMMENT 'Pending Qty',
  `grand_total` double(20,2) DEFAULT NULL,
  `purchase_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double(20,2) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `return_bit` int(1) DEFAULT NULL COMMENT 'Purchase return raised',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_purchaseitems
#

DROP TABLE IF EXISTS `db_purchaseitems`;

CREATE TABLE `db_purchaseitems` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(5) DEFAULT NULL,
  `purchase_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `purchase_qty` double(20,2) DEFAULT NULL,
  `price_per_unit` double(20,2) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,2) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_discount_per` double(20,2) DEFAULT NULL,
  `discount_amt` double(20,2) DEFAULT NULL,
  `unit_total_cost` double(20,2) DEFAULT NULL,
  `total_cost` double(20,2) DEFAULT NULL,
  `profit_margin_per` double(20,2) DEFAULT NULL,
  `unit_sales_price` double(20,2) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_input` double(20,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_purchaseitemsreturn
#

DROP TABLE IF EXISTS `db_purchaseitemsreturn`;

CREATE TABLE `db_purchaseitemsreturn` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(5) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `return_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `return_qty` double(20,2) DEFAULT NULL,
  `price_per_unit` double(20,2) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,2) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_discount_per` double(20,2) DEFAULT NULL,
  `discount_amt` double(20,2) DEFAULT NULL,
  `unit_total_cost` double(20,2) DEFAULT NULL,
  `total_cost` double(20,2) DEFAULT NULL,
  `profit_margin_per` double(20,2) DEFAULT NULL,
  `unit_sales_price` double(20,2) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_input` double(20,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_purchasepayments
#

DROP TABLE IF EXISTS `db_purchasepayments`;

CREATE TABLE `db_purchasepayments` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,2) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_purchasepaymentsreturn
#

DROP TABLE IF EXISTS `db_purchasepaymentsreturn`;

CREATE TABLE `db_purchasepaymentsreturn` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,2) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_purchasereturn
#

DROP TABLE IF EXISTS `db_purchasereturn`;

CREATE TABLE `db_purchasereturn` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) DEFAULT NULL,
  `return_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `return_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,2) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,2) DEFAULT NULL,
  `discount_to_all_input` double(20,2) DEFAULT NULL,
  `discount_to_all_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,2) DEFAULT NULL,
  `subtotal` double(20,2) DEFAULT NULL COMMENT 'Purchased qty',
  `round_off` double(20,2) DEFAULT NULL COMMENT 'Pending Qty',
  `grand_total` double(20,2) DEFAULT NULL,
  `return_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double(20,2) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_roles
#

DROP TABLE IF EXISTS `db_roles`;

CREATE TABLE `db_roles` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_roles` (`id`, `role_name`, `description`, `status`) VALUES (1, 'Admin', 'All Rights Permitted.', 1);
INSERT INTO `db_roles` (`id`, `role_name`, `description`, `status`) VALUES (2, 'Owner', '', 1);
INSERT INTO `db_roles` (`id`, `role_name`, `description`, `status`) VALUES (3, 'Clerk', '', 1);


#
# TABLE STRUCTURE FOR: db_sales
#

DROP TABLE IF EXISTS `db_sales`;

CREATE TABLE `db_sales` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `sales_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_date` date DEFAULT NULL,
  `sales_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,2) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,2) DEFAULT NULL,
  `discount_to_all_input` double(20,2) DEFAULT NULL,
  `discount_to_all_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,2) DEFAULT NULL,
  `subtotal` double(20,2) DEFAULT NULL,
  `round_off` double(20,2) DEFAULT NULL,
  `grand_total` double(20,2) DEFAULT NULL,
  `sales_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double(20,2) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `pos` int(1) DEFAULT NULL COMMENT '1=yes 0=no',
  `status` int(1) DEFAULT NULL,
  `return_bit` int(1) DEFAULT NULL COMMENT 'sales return raised',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (3, 'SL0001', NULL, '2022-02-03', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '3.00', '0.00', '3.00', NULL, 'Paid', '3.00', '2022-02-03', '09:22:01 am', 'justiniano', '107.72.164.16', '107.72.164.16', NULL, 1, 1, 1);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (4, 'SL0004', NULL, '2022-02-09', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '19.78', '0.00', '19.78', NULL, 'Paid', '19.78', '2022-02-09', '09:33:31 am', 'justiniano', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (5, 'SL0005', NULL, '2022-02-11', 'Final', 4, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '4.18', '0.00', '4.18', NULL, 'Paid', '4.18', '2022-02-11', '08:14:09 am', 'justiniano', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (6, 'SL0006', '202202/123', '2022-02-11', 'Quotation', 5, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '3611.00', NULL, '3611.00', '', 'Unpaid', '0.00', '2022-02-11', '09:15:26 am', 'justiniano', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', NULL, NULL, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (7, 'SL0007', NULL, '2022-02-17', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '15.43', '0.00', '15.43', NULL, 'Paid', '15.43', '2022-02-17', '11:56:25 am', 'justiniano', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (8, 'SL0008', NULL, '2022-02-17', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '93.66', '0.00', '93.66', NULL, 'Paid', '93.66', '2022-02-17', '12:51:48 pm', 'justiniano', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (9, 'SL0009', NULL, '2022-06-06', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '6.54', '0.00', '6.54', NULL, 'Paid', '6.54', '2022-06-06', '01:04:21 am', 'admin', '186.85.71.135', 'static-ip-1868571135.cable.net.co', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (10, 'SL0010', NULL, '2022-06-06', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '107.69', '0.00', '107.69', NULL, 'Paid', '107.69', '2022-06-06', '09:20:17 am', 'admin', '45.229.41.216', '45.229.41.216', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (11, 'SL0011', NULL, '2022-08-27', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '52.26', '0.00', '52.26', NULL, 'Paid', '52.26', '2022-08-27', '12:21:45 am', 'admin', '190.149.71.206', '190.149.71.206', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (12, 'SL0012', NULL, '2022-08-27', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '9.83', '0.00', '9.83', NULL, 'Paid', '9.83', '2022-08-27', '12:23:16 am', 'admin', '190.149.71.206', '190.149.71.206', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (13, 'SL0013', NULL, '2022-10-01', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '1.62', '0.00', '1.62', NULL, 'Paid', '1.62', '2022-10-01', '09:59:12 am', 'admin', '102.223.24.178', '102.223.24.178', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (14, 'SL0014', NULL, '2022-10-16', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '43.44', '0.00', '43.44', NULL, 'Paid', '43.44', '2022-10-16', '07:35:45 pm', 'admin', '190.14.141.2', '190.14.141.2', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (15, 'SL0015', NULL, '2022-11-04', 'Final', 2, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '1581.06', '0.00', '1581.06', NULL, 'Paid', '1581.06', '2022-11-04', '05:03:25 pm', 'admin', '190.239.152.159', '190.239.152.159', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (16, 'SL0016', NULL, '2022-11-11', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '21.90', '0.00', '21.90', NULL, 'Paid', '21.90', '2022-11-11', '11:53:23 pm', 'admin', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (17, 'SL0017', NULL, '2022-11-11', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '21.90', '0.00', '21.90', NULL, 'Paid', '21.90', '2022-11-11', '11:53:28 pm', 'admin', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (18, 'SL0018', NULL, '2022-11-11', 'Final', 2, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '21.90', '0.00', '21.90', NULL, 'Paid', '21.90', '2022-11-11', '11:53:32 pm', 'admin', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (19, 'SL0019', NULL, '2022-11-11', 'Final', 2, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '21.90', '0.00', '21.90', NULL, 'Paid', '21.90', '2022-11-11', '11:53:59 pm', 'admin', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (20, 'SL0020', NULL, '2022-12-07', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '120.83', '0.00', '120.83', NULL, 'Paid', '120.83', '2022-12-07', '03:24:22 pm', 'admin', '181.211.10.26', '26.10.211.181.static.anycast.cnt-grms.ec', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (21, 'SL0021', NULL, '2022-12-07', 'Final', 3, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '2.51', '0.00', '2.51', NULL, 'Paid', '2.51', '2022-12-07', '05:22:52 pm', 'admin', '190.166.7.28', '28.7.166.190.f.sta.codetel.net.do', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (22, 'SL0022', NULL, '2022-12-08', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '7.27', '0.00', '7.27', NULL, 'Paid', '7.27', '2022-12-08', '01:26:09 am', 'admin', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (23, 'SL0023', NULL, '2022-12-08', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '42.00', '0.00', '42.00', NULL, 'Paid', '42.00', '2022-12-08', '01:38:01 am', 'admin', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (24, 'SL0024', NULL, '2022-12-08', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '9.96', '0.00', '9.96', NULL, 'Paid', '9.96', '2022-12-08', '01:49:55 am', 'admin', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (25, 'SL0025', NULL, '2022-12-08', 'Final', 4, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '2.65', '0.00', '2.65', NULL, 'Paid', '2.65', '2022-12-08', '01:58:33 am', 'admin', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (26, 'SL0026', NULL, '2022-12-19', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '31.05', '0.00', '31.05', NULL, 'Paid', '31.05', '2022-12-19', '11:16:36 pm', 'admin', '2800:200:f488:99bb:d0e4:d2ed:4301:fe87', '2800:200:f488:99bb:d0e4:d2ed:4301:fe87', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (27, 'SL0027', NULL, '2022-12-21', 'Final', 2, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '6.49', '0.00', '6.49', NULL, 'Paid', '6.49', '2022-12-21', '10:29:45 am', 'admin', '190.110.45.6', 'corp-190-110-45-6.punto.net.ec', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (28, 'SL0028', NULL, '2022-12-24', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '6.63', '0.00', '6.63', NULL, 'Paid', '6.63', '2022-12-24', '01:26:33 am', 'admin', '190.237.88.234', '190.237.88.234', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (29, 'SL0029', NULL, '2022-12-26', 'Final', 3, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '1.62', '0.00', '1.62', NULL, 'Paid', '1.62', '2022-12-26', '05:20:26 pm', 'admin', '186.151.122.214', '186.151.122.214', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (30, 'SL0030', NULL, '2022-12-27', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '1.62', '0.00', '1.62', NULL, 'Paid', '1.62', '2022-12-27', '04:28:13 pm', 'admin', '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (31, 'SL0031', '3443434', '2022-12-27', 'Quotation', 2, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '1.58', NULL, '1.58', '', '', '11.00', '2022-12-27', '04:29:53 pm', 'admin', '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', NULL, NULL, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (32, 'SL0032', '', '2023-01-26', 'Final', 1, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '77.60', NULL, '77.60', '', 'Paid', '77.60', '2023-01-26', '10:43:52 am', 'admin', '186.32.100.2', '186.32.100.2', NULL, NULL, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (33, 'SL0033', NULL, '2023-01-26', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '115.00', '0.00', '115.00', NULL, 'Paid', '115.00', '2023-01-26', '10:51:58 am', 'admin', '186.32.100.2', '186.32.100.2', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (34, 'SL0034', NULL, '2023-01-29', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '5.00', '0.00', '5.00', NULL, 'Paid', '5.00', '2023-01-29', '04:22:07 am', 'admin', '190.83.61.27', '190.83.61.27', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (35, 'SL0035', NULL, '2023-02-01', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '5.00', '0.00', '5.00', NULL, 'Paid', '5.00', '2023-02-01', '06:31:05 pm', 'admin', '187.154.236.133', 'dsl-187-154-236-133-dyn.prod-infinitum.com.mx', NULL, 1, 1, NULL);
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (36, 'SL0036', NULL, '2023-02-08', 'Final', 1, NULL, '0.00', NULL, '0.00', '0.00', 'in_percentage', '0.00', '18.00', '0.00', '18.00', NULL, 'Paid', '18.00', '2023-02-08', '08:27:02 pm', 'admin', '45.191.88.207', '45.191.88.207', NULL, 1, 1, NULL);


#
# TABLE STRUCTURE FOR: db_salesitems
#

DROP TABLE IF EXISTS `db_salesitems`;

CREATE TABLE `db_salesitems` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `sales_id` int(5) DEFAULT NULL,
  `sales_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_qty` double(20,2) DEFAULT NULL,
  `price_per_unit` double(20,2) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,2) DEFAULT NULL,
  `discount_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_input` double(20,2) DEFAULT NULL,
  `discount_amt` double(20,2) DEFAULT NULL,
  `unit_total_cost` double(20,2) DEFAULT NULL,
  `total_cost` double(20,2) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `purchase_price` double(20,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (3, 3, 'Final', 1, '', '2.00', '1.45', 'Exclusive', 1, '0.30', 'Percentage', '0.00', '0.00', '1.60', '3.20', 1, '0.83');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (4, 4, 'Final', 16, '', '2.00', '8.95', 'Exclusive', 1, '1.88', 'Percentage', '0.00', '0.00', '9.89', '19.78', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (5, 5, 'Final', 120, '', '3.00', '1.25', 'Exclusive', 4, '0.43', 'Percentage', '0.00', '0.00', '1.39', '4.18', 1, '0.76');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (6, 6, 'Quotation', 129, '', '4.00', '106.72', 'Inclusive', NULL, NULL, 'Fixed', NULL, '0.00', '106.72', '426.88', 1, '92.80');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (7, 6, 'Quotation', 130, '', '4.00', '300.50', 'Inclusive', NULL, NULL, 'Fixed', NULL, '0.00', '300.50', '1202.00', 1, '273.18');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (8, 6, 'Quotation', 131, '', '4.00', '158.22', 'Inclusive', NULL, NULL, 'Percentage', NULL, '0.00', '158.22', '632.88', 1, '143.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (9, 6, 'Quotation', 132, '', '6.00', '116.94', 'Inclusive', NULL, NULL, 'Percentage', NULL, '0.00', '116.94', '701.64', 1, '97.45');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (10, 6, 'Quotation', 133, '', '4.00', '161.90', 'Inclusive', NULL, NULL, 'Percentage', NULL, '0.00', '161.90', '647.60', 1, '147.18');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (11, 7, 'Final', 92, '', '1.00', '5.99', 'Exclusive', 4, '0.69', 'Percentage', '0.00', '0.00', '6.68', '6.68', 1, '3.90');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (12, 7, 'Final', 91, '', '1.00', '4.49', 'Exclusive', 4, '0.52', 'Percentage', '0.00', '0.00', '5.01', '5.01', 1, '3.90');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (13, 7, 'Final', 36, '', '1.00', '3.35', 'Exclusive', 4, '0.39', 'Percentage', '0.00', '0.00', '3.74', '3.74', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (14, 8, 'Final', 166, '', '2.00', '42.00', 'Exclusive', 4, '9.66', 'Percentage', '0.00', '0.00', '46.83', '93.66', 1, '30.05');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (15, 9, 'Final', 1, '', '1.00', '1.45', 'Exclusive', 4, '0.17', 'Percentage', '0.00', '0.00', '1.62', '1.62', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (16, 9, 'Final', 5, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (17, 10, 'Final', 4, '', '1.00', '1.65', 'Exclusive', 1, '0.17', 'Percentage', '0.00', '0.00', '1.82', '1.82', 1, '1.09');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (18, 10, 'Final', 47, '', '1.00', '94.95', 'Exclusive', 4, '10.92', 'Percentage', '0.00', '0.00', '105.87', '105.87', 1, '73.53');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (19, 11, 'Final', 2, '', '1.00', '29.95', 'Exclusive', 1, '3.14', 'Percentage', '0.00', '0.00', '33.09', '33.09', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (20, 11, 'Final', 7, '', '2.00', '3.45', 'Exclusive', 1, '0.72', 'Percentage', '0.00', '0.00', '3.81', '7.62', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (21, 11, 'Final', 6, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (22, 11, 'Final', 10, '', '1.00', '5.95', 'Exclusive', 4, '0.68', 'Percentage', '0.00', '0.00', '6.63', '6.63', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (23, 12, 'Final', 5, '', '2.00', '4.45', 'Exclusive', 1, '0.93', 'Percentage', '0.00', '0.00', '4.92', '9.83', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (24, 13, 'Final', 1, '', '1.00', '1.45', 'Exclusive', 4, '0.17', 'Percentage', '0.00', '0.00', '1.62', '1.62', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (25, 14, 'Final', 1, '', '1.00', '1.45', 'Exclusive', 4, '0.17', 'Percentage', '0.00', '0.00', '1.62', '1.62', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (26, 14, 'Final', 2, '', '1.00', '29.95', 'Exclusive', 1, '3.14', 'Percentage', '0.00', '0.00', '33.09', '33.09', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (27, 14, 'Final', 3, '', '1.00', '2.95', 'Exclusive', 1, '0.31', 'Percentage', '0.00', '0.00', '3.26', '3.26', 1, '1.38');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (28, 14, 'Final', 4, '', '3.00', '1.65', 'Exclusive', 1, '0.52', 'Percentage', '0.00', '0.00', '1.82', '5.47', 1, '1.09');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (29, 15, 'Final', 131, '', '4.00', '158.22', 'Exclusive', 4, '72.78', 'Percentage', '0.00', '0.00', '176.42', '705.66', 1, '143.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (30, 15, 'Final', 129, '', '1.00', '106.72', 'Exclusive', 4, '12.27', 'Percentage', '0.00', '0.00', '118.99', '118.99', 1, '92.80');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (31, 15, 'Final', 133, '', '1.00', '161.90', 'Exclusive', 4, '18.62', 'Percentage', '0.00', '0.00', '180.52', '180.52', 1, '147.18');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (32, 15, 'Final', 132, '', '1.00', '116.94', 'Exclusive', 4, '13.45', 'Percentage', '0.00', '0.00', '130.39', '130.39', 1, '97.45');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (33, 15, 'Final', 46, '', '1.00', '99.95', 'Exclusive', 1, '10.49', 'Percentage', '0.00', '0.00', '110.44', '110.44', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (34, 15, 'Final', 130, '', '1.00', '300.50', 'Exclusive', 4, '34.56', 'Percentage', '0.00', '0.00', '335.06', '335.06', 1, '273.18');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (35, 16, 'Final', 1, '', '1.00', '1.45', 'Exclusive', 4, '0.17', 'Percentage', '0.00', '0.00', '1.62', '1.62', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (36, 16, 'Final', 5, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (37, 16, 'Final', 6, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (38, 16, 'Final', 7, '', '1.00', '3.45', 'Exclusive', 1, '0.36', 'Percentage', '0.00', '0.00', '3.81', '3.81', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (39, 16, 'Final', 11, '', '1.00', '5.95', 'Exclusive', 4, '0.68', 'Percentage', '0.00', '0.00', '6.63', '6.63', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (40, 17, 'Final', 1, '', '1.00', '1.45', 'Exclusive', 4, '0.17', 'Percentage', '0.00', '0.00', '1.62', '1.62', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (41, 17, 'Final', 5, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (42, 17, 'Final', 6, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (43, 17, 'Final', 7, '', '1.00', '3.45', 'Exclusive', 1, '0.36', 'Percentage', '0.00', '0.00', '3.81', '3.81', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (44, 17, 'Final', 11, '', '1.00', '5.95', 'Exclusive', 4, '0.68', 'Percentage', '0.00', '0.00', '6.63', '6.63', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (45, 18, 'Final', 1, '', '1.00', '1.45', 'Exclusive', 4, '0.17', 'Percentage', '0.00', '0.00', '1.62', '1.62', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (46, 18, 'Final', 5, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (47, 18, 'Final', 6, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (48, 18, 'Final', 7, '', '1.00', '3.45', 'Exclusive', 1, '0.36', 'Percentage', '0.00', '0.00', '3.81', '3.81', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (49, 18, 'Final', 11, '', '1.00', '5.95', 'Exclusive', 4, '0.68', 'Percentage', '0.00', '0.00', '6.63', '6.63', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (50, 19, 'Final', 1, '', '1.00', '1.45', 'Exclusive', 4, '0.17', 'Percentage', '0.00', '0.00', '1.62', '1.62', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (51, 19, 'Final', 5, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (52, 19, 'Final', 6, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (53, 19, 'Final', 7, '', '1.00', '3.45', 'Exclusive', 1, '0.36', 'Percentage', '0.00', '0.00', '3.81', '3.81', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (54, 19, 'Final', 11, '', '1.00', '5.95', 'Exclusive', 4, '0.68', 'Percentage', '0.00', '0.00', '6.63', '6.63', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (55, 20, 'Final', 43, '', '1.00', '3.35', 'Exclusive', 4, '0.39', 'Percentage', '0.00', '0.00', '3.74', '3.74', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (56, 20, 'Final', 47, '', '1.00', '94.95', 'Exclusive', 4, '10.92', 'Percentage', '0.00', '0.00', '105.87', '105.87', 1, '73.53');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (57, 20, 'Final', 45, '', '1.00', '3.35', 'Exclusive', 4, '0.39', 'Percentage', '0.00', '0.00', '3.74', '3.74', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (58, 20, 'Final', 37, '', '1.00', '3.35', 'Exclusive', 4, '0.39', 'Percentage', '0.00', '0.00', '3.74', '3.74', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (59, 20, 'Final', 38, '', '1.00', '3.35', 'Exclusive', 4, '0.39', 'Percentage', '0.00', '0.00', '3.74', '3.74', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (60, 21, 'Final', 167, '', '1.00', '2.25', 'Exclusive', 4, '0.26', 'Percentage', '0.00', '0.00', '2.51', '2.51', 1, '1.67');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (61, 22, 'Final', 167, '', '2.00', '2.25', 'Exclusive', 4, '0.52', 'Percentage', '0.00', '0.00', '2.51', '5.02', 1, '1.67');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (62, 22, 'Final', 168, '', '1.00', '2.25', 'Exclusive', 5, NULL, 'Percentage', '0.00', '0.00', '2.25', '2.25', 1, '1.25');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (63, 23, 'Final', 166, '', '1.00', '42.00', 'Inclusive', 4, '4.33', 'Percentage', '0.00', '0.00', '42.00', '42.00', 1, '26.95');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (64, 24, 'Final', 168, '', '2.00', '2.25', 'Exclusive', 5, NULL, 'Percentage', '0.00', '0.00', '2.25', '4.50', 1, '1.25');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (65, 24, 'Final', 167, '', '1.00', '2.25', 'Exclusive', 4, '0.26', 'Percentage', '0.00', '0.00', '2.51', '2.51', 1, '1.67');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (66, 24, 'Final', 160, '', '1.00', '2.65', 'Exclusive', 4, '0.30', 'Percentage', '0.00', '0.00', '2.95', '2.95', 1, '1.88');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (68, 25, 'Final', 160, '', '1.00', '2.65', 'Inclusive', 4, '0.27', 'Percentage', '0.00', '0.00', '2.65', '2.65', 1, '1.69');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (69, 26, 'Final', 1, '', '1.00', '1.45', 'Exclusive', 4, '0.17', 'Percentage', '0.00', '0.00', '1.62', '1.62', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (70, 26, 'Final', 6, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (71, 26, 'Final', 8, '', '1.00', '3.45', 'Exclusive', 1, '0.36', 'Percentage', '0.00', '0.00', '3.81', '3.81', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (72, 26, 'Final', 9, '', '1.00', '3.45', 'Exclusive', 4, '0.40', 'Percentage', '0.00', '0.00', '3.85', '3.85', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (73, 26, 'Final', 10, '', '1.00', '5.95', 'Exclusive', 4, '0.68', 'Percentage', '0.00', '0.00', '6.63', '6.63', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (74, 26, 'Final', 11, '', '1.00', '5.95', 'Exclusive', 4, '0.68', 'Percentage', '0.00', '0.00', '6.63', '6.63', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (75, 26, 'Final', 12, '', '1.00', '3.25', 'Exclusive', 1, '0.34', 'Percentage', '0.00', '0.00', '3.59', '3.59', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (76, 27, 'Final', 1, '', '2.00', '1.45', 'Exclusive', 4, '0.33', 'Percentage', '0.00', '0.00', '1.62', '3.23', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (77, 27, 'Final', 3, '', '1.00', '2.95', 'Exclusive', 1, '0.31', 'Percentage', '0.00', '0.00', '3.26', '3.26', 1, '1.38');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (78, 28, 'Final', 10, '', '1.00', '5.95', 'Exclusive', 4, '0.68', 'Percentage', '0.00', '0.00', '6.63', '6.63', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (79, 29, 'Final', 1, '', '1.00', '1.45', 'Exclusive', 4, '0.17', 'Percentage', '0.00', '0.00', '1.62', '1.62', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (80, 30, 'Final', 1, '', '1.00', '1.45', 'Exclusive', 4, '0.17', 'Percentage', '0.00', '0.00', '1.62', '1.62', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (81, 31, 'Quotation', 1, '', '1.00', '1.45', 'Exclusive', 1, '0.15', 'Percentage', '1.18', '0.02', '1.59', '1.58', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (82, 32, 'Final', 1, '', '48.00', '1.45', 'Exclusive', 4, '8.00', 'Percentage', NULL, '0.00', '1.62', '77.60', 1, '0.84');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (83, 33, 'Final', 170, '', '2.00', '52.50', 'Inclusive', 2, '1.04', 'Percentage', '0.00', '0.00', '52.50', '105.00', 1, '42.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (84, 33, 'Final', 3, '', '2.00', '2.95', 'Exclusive', 1, '0.62', 'Percentage', '0.00', '0.00', '3.26', '6.52', 1, '1.38');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (85, 33, 'Final', 4, '', '2.00', '1.65', 'Exclusive', 1, '0.35', 'Percentage', '0.00', '0.00', '1.82', '3.65', 1, '1.09');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (86, 34, 'Final', 3, '', '1.00', '2.95', 'Exclusive', 1, '0.31', 'Percentage', '0.00', '0.00', '3.26', '3.26', 1, '1.38');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (87, 34, 'Final', 4, '', '1.00', '1.65', 'Exclusive', 1, '0.17', 'Percentage', '0.00', '0.00', '1.82', '1.82', 1, '1.09');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (88, 35, 'Final', 6, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (89, 36, 'Final', 6, '', '1.00', '4.45', 'Exclusive', 1, '0.47', 'Percentage', '0.00', '0.00', '4.92', '4.92', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (90, 36, 'Final', 10, '', '1.00', '5.95', 'Exclusive', 4, '0.68', 'Percentage', '0.00', '0.00', '6.63', '6.63', 1, '0.00');
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (91, 36, 'Final', 11, '', '1.00', '5.95', 'Exclusive', 4, '0.68', 'Percentage', '0.00', '0.00', '6.63', '6.63', 1, '0.00');


#
# TABLE STRUCTURE FOR: db_salesitemsreturn
#

DROP TABLE IF EXISTS `db_salesitemsreturn`;

CREATE TABLE `db_salesitemsreturn` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `sales_id` int(5) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `return_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_qty` double(20,2) DEFAULT NULL,
  `price_per_unit` double(20,2) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,2) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_input` double(20,2) DEFAULT NULL,
  `discount_amt` double(20,2) DEFAULT NULL,
  `discount_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_total_cost` double(20,2) DEFAULT NULL,
  `total_cost` double(20,2) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `purchase_price` double(20,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_salesitemsreturn` (`id`, `sales_id`, `return_id`, `return_status`, `item_id`, `description`, `return_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `discount_input`, `discount_amt`, `discount_type`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (1, NULL, 1, 'Return', 1, '', '2.00', '1.45', 1, '0.30', 'Exclusive', NULL, '0.00', 'Percentage', '1.60', '3.20', 1, '0.83');
INSERT INTO `db_salesitemsreturn` (`id`, `sales_id`, `return_id`, `return_status`, `item_id`, `description`, `return_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `discount_input`, `discount_amt`, `discount_type`, `unit_total_cost`, `total_cost`, `status`, `purchase_price`) VALUES (2, 3, 2, 'Return', 1, '', '2.00', '1.45', 1, '0.30', 'Exclusive', NULL, '0.00', 'Percentage', '1.60', '3.20', 1, '0.83');


#
# TABLE STRUCTURE FOR: db_salespayments
#

DROP TABLE IF EXISTS `db_salespayments`;

CREATE TABLE `db_salespayments` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `sales_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,2) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_return` double(20,2) DEFAULT NULL COMMENT 'Refunding the greater amount',
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (3, 3, '2022-02-03', 'Cash', '3.00', '', '2.00', '107.72.164.16', '107.72.164.16', '09:22:01', '2022-02-03', 'justiniano', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (4, 4, '2022-02-09', 'Cash', '19.78', '', '0.22', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '09:33:31', '2022-02-09', 'justiniano', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (5, 5, '2022-02-11', 'ATH Movil', '4.18', '', '0.00', '107.77.215.226', 'mobile-107-77-215-226.mobile.att.net', '08:14:09', '2022-02-11', 'justiniano', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (6, 7, '2022-02-17', 'Cash', '15.43', '', '4.57', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '11:56:25', '2022-02-17', 'justiniano', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (7, 8, '2022-02-17', 'Cash', '93.66', 'Paid By Cash', '0.00', '107.77.216.171', 'mobile-107-77-216-171.mobile.att.net', '12:51:48', '2022-02-17', 'justiniano', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (8, 9, '2022-06-06', 'Cash', '6.54', 'Paid By Cash', '0.00', '186.85.71.135', 'static-ip-1868571135.cable.net.co', '01:04:21', '2022-06-06', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (9, 10, '2022-06-06', 'Cash', '107.69', '', '92.31', '45.229.41.216', '45.229.41.216', '09:20:17', '2022-06-06', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (10, 11, '2022-08-27', 'Cash', '52.26', 'Paid By Cash', '0.00', '190.149.71.206', '190.149.71.206', '12:21:45', '2022-08-27', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (11, 12, '2022-08-27', 'Cash', '9.83', 'fernadno', '0.17', '190.149.71.206', '190.149.71.206', '12:23:16', '2022-08-27', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (12, 13, '2022-10-01', 'Cash', '1.62', '', '0.38', '102.223.24.178', '102.223.24.178', '09:59:12', '2022-10-01', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (13, 14, '2022-10-16', 'Cash', '43.44', '', '456.56', '190.14.141.2', '190.14.141.2', '07:35:45', '2022-10-16', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (14, 15, '2022-11-04', 'Cash', '1581.06', 'Paid By Cash', '0.00', '190.239.152.159', '190.239.152.159', '05:03:25', '2022-11-04', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (15, 16, '2022-11-11', 'Cash', '21.90', 'Paid By Cash', '0.00', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '11:53:23', '2022-11-11', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (16, 17, '2022-11-11', 'Cash', '21.90', 'Paid By Cash', '0.00', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '11:53:28', '2022-11-11', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (17, 18, '2022-11-11', 'Cash', '21.90', 'Paid By Cash', '0.00', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '11:53:32', '2022-11-11', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (18, 19, '2022-11-11', 'Cash', '21.90', '', '1.10', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '2800:200:e880:15d1:fdf8:23ee:95eb:c5a9', '11:53:59', '2022-11-11', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (19, 20, '2022-12-07', 'Cash', '120.83', 'Paid By Cash', '0.00', '181.211.10.26', '26.10.211.181.static.anycast.cnt-grms.ec', '03:24:22', '2022-12-07', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (20, 21, '2022-12-07', 'Cash', '2.51', '', '0.49', '190.166.7.28', '28.7.166.190.f.sta.codetel.net.do', '05:22:52', '2022-12-07', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (21, 22, '2022-12-08', 'Cash', '7.27', '', '0.73', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '01:26:09', '2022-12-08', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (22, 23, '2022-12-08', 'Cash', '42.00', 'Paid By Cash', '0.00', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '01:38:01', '2022-12-08', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (23, 24, '2022-12-08', 'Cash', '9.96', '', '0.04', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '01:49:55', '2022-12-08', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (24, 25, '2022-12-08', 'Cash', '2.65', 'Paid By Cash', '0.00', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '2803:1400:8000:4646:15b9:5051:9c5a:7cbb', '01:59:02', '2022-12-08', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (25, 26, '2022-12-19', 'Cash', '31.05', 'Paid By Cash', '0.00', '2800:200:f488:99bb:d0e4:d2ed:4301:fe87', '2800:200:f488:99bb:d0e4:d2ed:4301:fe87', '11:16:36', '2022-12-19', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (26, 27, '2022-12-21', 'Cash', '6.49', 'Paid By Cash', '0.00', '190.110.45.6', 'corp-190-110-45-6.punto.net.ec', '10:29:45', '2022-12-21', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (27, 28, '2022-12-24', 'Cash', '6.63', 'Paid By Cash', '0.00', '190.237.88.234', '190.237.88.234', '01:26:33', '2022-12-24', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (28, 29, '2022-12-26', 'Cash', '1.62', 'Paid By Cash', '0.00', '186.151.122.214', '186.151.122.214', '05:20:26', '2022-12-26', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (29, 30, '2022-12-27', 'Cash', '1.62', 'Paid By Cash', '0.00', '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', '04:28:13', '2022-12-27', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (30, 31, '2022-12-27', 'Cash', '11.00', 'ewe', NULL, '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', '2001:1388:a45:5391:b5a3:1817:7a1b:9aeb', '04:29:53', '2022-12-27', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (31, 32, '2023-01-26', 'Cash', '77.60', '', NULL, '186.32.100.2', '186.32.100.2', '10:43:52', '2023-01-26', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (32, 33, '2023-01-26', 'Cash', '115.00', '', '0.00', '186.32.100.2', '186.32.100.2', '10:51:58', '2023-01-26', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (33, 34, '2023-01-29', 'Cash', '5.00', 'Paid By Cash', '0.00', '190.83.61.27', '190.83.61.27', '04:22:07', '2023-01-29', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (34, 35, '2023-02-01', 'Cash', '5.00', '', '25.00', '187.154.236.133', 'dsl-187-154-236-133-dyn.prod-infinitum.com.mx', '06:31:05', '2023-02-01', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (35, 36, '2023-02-08', 'Cash', '18.00', 'Paid By Cash', '0.00', '45.191.88.207', '45.191.88.207', '08:27:02', '2023-02-08', 'admin', 1);


#
# TABLE STRUCTURE FOR: db_salespaymentsreturn
#

DROP TABLE IF EXISTS `db_salespaymentsreturn`;

CREATE TABLE `db_salespaymentsreturn` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `sales_id` int(5) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,2) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_return` double(20,2) DEFAULT NULL COMMENT 'Refunding the greater amount',
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_salespaymentsreturn` (`id`, `sales_id`, `return_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (1, NULL, 1, '2022-02-03', 'Cash', '3.00', '', NULL, '107.72.164.16', '107.72.164.16', '09:26:24', '2022-02-03', 'justiniano', 1);
INSERT INTO `db_salespaymentsreturn` (`id`, `sales_id`, `return_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (2, 3, 2, '2022-02-03', 'Cash', '3.00', '', NULL, '107.72.164.16', '107.72.164.16', '09:44:24', '2022-02-03', 'justiniano', 1);


#
# TABLE STRUCTURE FOR: db_salesreturn
#

DROP TABLE IF EXISTS `db_salesreturn`;

CREATE TABLE `db_salesreturn` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `sales_id` int(5) DEFAULT NULL,
  `return_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `return_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,2) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,2) DEFAULT NULL,
  `discount_to_all_input` double(20,2) DEFAULT NULL,
  `discount_to_all_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,2) DEFAULT NULL,
  `subtotal` double(20,2) DEFAULT NULL,
  `round_off` double(20,2) DEFAULT NULL,
  `grand_total` double(20,2) DEFAULT NULL,
  `return_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double(20,2) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `pos` int(1) DEFAULT NULL COMMENT '1=yes 0=no',
  `status` int(1) DEFAULT NULL,
  `return_bit` int(1) DEFAULT NULL COMMENT 'Return raised or not 1 or null',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_salesreturn` (`id`, `sales_id`, `return_code`, `reference_no`, `return_date`, `return_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `return_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (1, NULL, 'PR0001', '', '2022-02-03', 'Return', 1, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '3.20', '-0.20', '3.00', '', 'Paid', '3.00', '2022-02-03', '09:25:06 am', 'justiniano', '107.72.164.16', '107.72.164.16', NULL, NULL, 1, NULL);
INSERT INTO `db_salesreturn` (`id`, `sales_id`, `return_code`, `reference_no`, `return_date`, `return_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `return_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`) VALUES (2, 3, 'PR0002', '', '2022-02-03', 'Return', 1, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '3.20', '-0.20', '3.00', '', 'Paid', '3.00', '2022-02-03', '09:44:24 am', 'justiniano', '107.72.164.16', '107.72.164.16', NULL, NULL, 1, NULL);


#
# TABLE STRUCTURE FOR: db_sitesettings
#

DROP TABLE IF EXISTS `db_sitesettings`;

CREATE TABLE `db_sitesettings` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `version` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'path',
  `language_id` int(5) DEFAULT NULL,
  `currency_id` int(5) DEFAULT NULL,
  `currency_placement` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_format` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_format` int(5) DEFAULT NULL,
  `sales_discount` double(20,2) DEFAULT NULL,
  `site_url` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_desc` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currencysymbol_id` int(5) DEFAULT NULL,
  `regno_key` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_url` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_url` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube_url` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `analytic_code` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fav_icon` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'path',
  `footer_logo` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'path',
  `company_id` int(1) DEFAULT NULL,
  `purchase_code` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_return` int(1) DEFAULT NULL COMMENT 'show in pos',
  `sales_invoice_format_id` int(5) DEFAULT NULL,
  `sales_invoice_footer_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `round_off` int(1) DEFAULT NULL COMMENT '1=Enble, 0=Disable',
  `machine_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `domain` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_upi_code` int(1) DEFAULT 0,
  `unique_code` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disable_tax` int(1) DEFAULT 0 COMMENT 'If set Disable the tax from app',
  PRIMARY KEY (`id`),
  KEY `currencysymbol_id` (`currencysymbol_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_sitesettings` (`id`, `version`, `site_name`, `logo`, `language_id`, `currency_id`, `currency_placement`, `timezone`, `date_format`, `time_format`, `sales_discount`, `site_url`, `site_title`, `meta_title`, `meta_desc`, `meta_keywords`, `currencysymbol_id`, `regno_key`, `copyright`, `facebook_url`, `twitter_url`, `youtube_url`, `analytic_code`, `fav_icon`, `footer_logo`, `company_id`, `purchase_code`, `change_return`, `sales_invoice_format_id`, `sales_invoice_footer_text`, `round_off`, `machine_id`, `domain`, `show_upi_code`, `unique_code`, `disable_tax`) VALUES (1, '2.0', 'VENTAS MULTISUCURSAL', 'icono1.png', 7, 56, 'Left', 'America/Lima\r\n', 'dd-mm-yyyy', 12, '0.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 3, ' This is footer text. You can set it from Site Settings.', 1, '1', 'www.babiato.co', 0, 'i49trbfy8kmd20gs6xp51z3vwe7lao', 0);


#
# TABLE STRUCTURE FOR: db_smsapi
#

DROP TABLE IF EXISTS `db_smsapi`;

CREATE TABLE `db_smsapi` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `info` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key` varchar(600) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key_value` varchar(600) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delete_bit` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (144, 'url', 'weblink', 'http://www.example.in/api/sendhttp.php', NULL);
INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (145, 'mobile', 'mobiles', '', NULL);
INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (146, 'message', 'message', '', NULL);
INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (147, '', 'authkey', 'xxxxxxxxxxxxxxxxxxxx', NULL);
INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (148, '', 'sender', 'ULTPOS', NULL);
INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (149, '', 'route', '1', NULL);


#
# TABLE STRUCTURE FOR: db_smstemplates
#

DROP TABLE IF EXISTS `db_smstemplates`;

CREATE TABLE `db_smstemplates` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variables` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `undelete_bit` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_smstemplates` (`id`, `template_name`, `content`, `variables`, `company_id`, `status`, `undelete_bit`) VALUES (1, 'GREETING TO CUSTOMER ON SALES', 'Hi {{customer_name}},\r\nYour sales Id is {{sales_id}},\r\nSales Date {{sales_date}},\r\nTotal amount  {{sales_amount}},\r\nYou have paid  {{paid_amt}},\r\nand customer total due amount is  {{cust_tot_due_amt}}\r\nThank you Visit Again', '{{customer_name}}<br>\r\n{{sales_id}}<br>\r\n{{sales_date}}<br>\r\n{{sales_amount}}<br>\r\n{{paid_amt}}<br>\r\n{{cust_tot_due_amt}}<br>\r\n{{invoice_due_amt}}<br>\r\n{{company_name}}<br>\r\n{{company_mobile}}<br>\r\n{{company_address}}<br>\r\n{{company_website}}<br>\r\n{{company_email}}<br>', NULL, 1, 1);
INSERT INTO `db_smstemplates` (`id`, `template_name`, `content`, `variables`, `company_id`, `status`, `undelete_bit`) VALUES (2, 'GREETING TO CUSTOMER ON SALES RETURN', 'Hi {{customer_name}},\r\nYour sales return Id is {{return_id}},\r\nReturn Date {{return_date}},\r\nTotal amount  {{return_amount}},\r\nWe paid  {{paid_amt}},\r\nand customer total due amount is  {{cust_tot_due_amt}}\r\nThank you Visit Again', '{{customer_name}}<br>\r\n{{return_id}}<br>\r\n{{return_date}}<br>\r\n{{return_amount}}<br>\r\n{{paid_amt}}<br>\r\n{{cust_tot_due_amt}}<br>\r\n{{invoice_due_amt}}<br>\r\n{{company_name}}<br>\r\n{{company_mobile}}<br>\r\n{{company_address}}<br>\r\n{{company_website}}<br>\r\n{{company_email}}<br>', NULL, 1, 1);


#
# TABLE STRUCTURE FOR: db_sobpayments
#

DROP TABLE IF EXISTS `db_sobpayments`;

CREATE TABLE `db_sobpayments` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,2) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_states
#

DROP TABLE IF EXISTS `db_states`;

CREATE TABLE `db_states` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `state_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(4050) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_id` int(5) DEFAULT NULL,
  `country` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `added_on` date DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (23, 'ST0001', 'Karnataka', 'CNT0001', NULL, 'India', '2017-07-10', 1, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (24, 'ST0024', 'Maharashtra', 'CNT0001', NULL, 'India', '2018-04-13', 1, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (25, 'ST0025', 'Andhra Pradesh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (26, 'ST0026', 'Arunachal Pradesh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (27, 'ST0027', 'Assam', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (28, 'ST0028', 'Bihar', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (29, 'ST0029', 'Chhattisgarh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (30, 'ST0030', 'Goa', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (31, 'ST0031', 'Gujarat', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (32, 'ST0032', 'Haryana', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (33, 'ST0033', 'Himachal Pradesh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (34, 'ST0034', 'Jammu and Kashmir', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (35, 'ST0035', 'Jharkhand', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (36, 'ST0036', 'Kerala', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (37, 'ST0037', 'Madhya Pradesh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (38, 'ST0038', 'Manipur', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (39, 'ST0039', 'Meghalaya', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (40, 'ST0040', 'Mizoram', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (41, 'ST0041', 'Nagaland', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (42, 'ST0042', 'Odisha', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (43, 'ST0043', 'Punjab', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (44, 'ST0044', 'Rajasthan', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (46, 'ST0046', 'Tamil Nadu', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (47, 'ST0047', 'Telangana', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (48, 'ST0048', 'Tripura', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (49, 'ST0049', 'Uttar Pradesh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (50, 'ST0050', 'Uttarakhand', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (51, 'ST0051', 'West Bengal', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (52, NULL, 'New York', NULL, NULL, 'USA', NULL, NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (53, NULL, 'Delhi', NULL, NULL, 'India', NULL, NULL, 1);
INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (54, NULL, 'PR', NULL, NULL, 'Puerto Rico', NULL, NULL, 1);


#
# TABLE STRUCTURE FOR: db_stockentry
#

DROP TABLE IF EXISTS `db_stockentry`;

CREATE TABLE `db_stockentry` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `entry_date` date DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `qty` int(5) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=226 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (3, '2022-02-02', 1, 60, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (4, '2022-02-02', 1, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (5, '2022-02-02', 2, 2, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (6, '2022-02-02', 2, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (7, '2022-02-02', 3, 11, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (8, '2022-02-02', 3, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (9, '2022-02-02', 4, 17, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (10, '2022-02-02', 4, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (11, '2022-02-02', 5, 4, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (12, '2022-02-02', 5, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (13, '2022-02-02', 6, 11, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (14, '2022-02-02', 6, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (15, '2022-02-02', 7, 3, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (16, '2022-02-02', 7, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (17, '2022-02-02', 8, 3, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (18, '2022-02-02', 8, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (19, '2022-02-02', 9, 1, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (20, '2022-02-02', 9, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (21, '2022-02-02', 10, 12, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (22, '2022-02-02', 10, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (23, '2022-02-02', 11, 12, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (24, '2022-02-02', 11, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (25, '2022-02-02', 12, 12, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (26, '2022-02-02', 12, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (27, '2022-02-02', 13, 2, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (28, '2022-02-02', 13, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (29, '2022-02-02', 14, 3, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (30, '2022-02-02', 14, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (31, '2022-02-02', 15, 11, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (32, '2022-02-02', 15, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (33, '2022-02-02', 16, 7, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (34, '2022-02-02', 16, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (35, '2022-02-02', 17, 11, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (36, '2022-02-02', 17, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (37, '2022-02-02', 18, 5, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (38, '2022-02-02', 18, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (39, '2022-02-02', 19, 11, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (40, '2022-02-02', 19, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (41, '2022-02-02', 20, 4, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (42, '2022-02-02', 20, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (43, '2022-02-02', 21, 10, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (44, '2022-02-02', 21, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (45, '2022-02-02', 22, 83, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (46, '2022-02-02', 22, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (47, '2022-02-02', 23, 11, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (48, '2022-02-02', 23, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (49, '2022-02-02', 24, 5, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (50, '2022-02-02', 24, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (51, '2022-02-02', 25, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (52, '2022-02-02', 25, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (53, '2022-02-02', 26, 5, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (54, '2022-02-02', 26, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (55, '2022-02-02', 27, 3, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (56, '2022-02-02', 27, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (57, '2022-02-02', 28, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (58, '2022-02-02', 28, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (59, '2022-02-02', 29, 5, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (60, '2022-02-02', 29, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (61, '2022-02-02', 30, 5, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (62, '2022-02-02', 30, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (63, '2022-02-02', 31, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (64, '2022-02-02', 31, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (65, '2022-02-02', 32, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (66, '2022-02-02', 32, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (67, '2022-02-02', 33, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (68, '2022-02-02', 33, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (69, '2022-02-02', 34, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (70, '2022-02-02', 34, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (71, '2022-02-02', 35, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (72, '2022-02-02', 35, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (73, '2022-02-02', 36, 7, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (74, '2022-02-02', 36, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (75, '2022-02-02', 37, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (76, '2022-02-02', 37, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (77, '2022-02-02', 38, 4, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (78, '2022-02-02', 38, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (79, '2022-02-02', 39, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (80, '2022-02-02', 39, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (81, '2022-02-02', 40, 5, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (82, '2022-02-02', 40, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (83, '2022-02-02', 41, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (84, '2022-02-02', 41, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (85, '2022-02-02', 42, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (86, '2022-02-02', 42, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (87, '2022-02-02', 43, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (88, '2022-02-02', 43, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (89, '2022-02-02', 44, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (90, '2022-02-02', 44, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (91, '2022-02-02', 45, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (92, '2022-02-02', 45, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (93, '2022-02-02', 46, 1, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (94, '2022-02-02', 46, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (95, '2022-02-02', 47, 3, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (96, '2022-02-02', 47, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (97, '2022-02-02', 48, 6, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (98, '2022-02-02', 48, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (99, '2022-02-02', 49, 2, NULL, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (100, '2022-02-02', 49, 0, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (101, '2022-02-04', 50, 24, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (103, '2022-02-04', 52, 5, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (104, '2022-02-04', 53, 5, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (105, '2022-02-04', 54, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (106, '2022-02-04', 55, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (107, '2022-02-04', 56, 5, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (108, '2022-02-04', 57, 9, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (109, '2022-02-04', 58, 8, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (110, '2022-02-04', 59, 4, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (111, '2022-02-04', 60, 5, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (112, '2022-02-04', 61, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (113, '2022-02-04', 62, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (114, '2022-02-05', 63, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (115, '2022-02-05', 64, 7, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (116, '2022-02-05', 65, 9, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (117, '2022-02-05', 66, 1, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (118, '2022-02-05', 67, 11, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (119, '2022-02-05', 68, 1, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (120, '2022-02-05', 69, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (121, '2022-02-05', 70, 1, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (122, '2022-02-05', 71, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (123, '2022-02-05', 72, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (124, '2022-02-05', 73, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (125, '2022-02-05', 74, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (126, '2022-02-05', 75, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (127, '2022-02-05', 76, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (128, '2022-02-05', 77, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (129, '2022-02-05', 78, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (130, '2022-02-05', 79, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (131, '2022-02-05', 80, 20, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (132, '2022-02-05', 81, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (133, '2022-02-05', 82, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (134, '2022-02-05', 83, 8, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (135, '2022-02-05', 84, 8, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (136, '2022-02-05', 85, 8, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (137, '2022-02-05', 86, 4, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (138, '2022-02-05', 87, 7, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (139, '2022-02-05', 88, 11, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (140, '2022-02-05', 89, 7, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (141, '2022-02-05', 90, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (142, '2022-02-05', 91, 8, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (143, '2022-02-05', 92, 24, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (144, '2022-02-05', 93, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (145, '2022-02-05', 94, 1, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (146, '2022-02-05', 95, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (147, '2022-02-05', 96, 5, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (148, '2022-02-05', 97, 5, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (149, '2022-02-05', 98, 7, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (150, '2022-02-05', 99, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (151, '2022-02-05', 100, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (152, '2022-02-05', 101, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (153, '2022-02-07', 1, -2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (154, '2022-02-07', 102, 8, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (155, '2022-02-07', 103, 4, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (156, '2022-02-07', 104, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (158, '2022-02-09', 105, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (159, '2022-02-09', 106, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (160, '2022-02-09', 107, 1, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (161, '2022-02-09', 108, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (162, '2022-02-09', 109, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (163, '2022-02-09', 110, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (164, '2022-02-09', 111, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (165, '2022-02-09', 112, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (166, '2022-02-09', 113, 5, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (167, '2022-02-09', 114, 4, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (168, '2022-02-09', 115, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (169, '2022-02-09', 116, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (170, '2022-02-09', 117, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (171, '2022-02-09', 118, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (172, '2022-02-09', 119, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (173, '2022-02-09', 120, 30, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (174, '2022-02-09', 121, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (175, '2022-02-09', 122, 7, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (176, '2022-02-09', 123, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (177, '2022-02-09', 124, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (178, '2022-02-09', 125, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (179, '2022-02-11', 126, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (180, '2022-02-11', 127, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (181, '2022-02-11', 128, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (182, '2022-02-11', 129, 8, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (183, '2022-02-11', 130, 8, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (184, '2022-02-11', 131, 8, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (185, '2022-02-11', 132, 8, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (186, '2022-02-11', 133, 8, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (187, '2022-02-11', 134, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (188, '2022-02-11', 135, 246, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (189, '2022-02-11', 136, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (190, '2022-02-11', 137, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (191, '2022-02-11', 138, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (192, '2022-02-11', 139, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (193, '2022-02-11', 140, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (194, '2022-02-11', 141, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (195, '2022-02-11', 142, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (196, '2022-02-11', 143, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (197, '2022-02-11', 144, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (198, '2022-02-11', 145, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (199, '2022-02-11', 146, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (200, '2022-02-11', 147, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (201, '2022-02-11', 148, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (202, '2022-02-15', 149, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (203, '2022-02-15', 115, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (204, '2022-02-15', 150, 1, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (205, '2022-02-15', 151, 1, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (206, '2022-02-15', 152, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (207, '2022-02-15', 153, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (208, '2022-02-15', 154, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (209, '2022-02-15', 155, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (210, '2022-02-16', 156, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (211, '2022-02-16', 157, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (212, '2022-02-16', 158, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (213, '2022-02-16', 159, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (214, '2022-02-16', 160, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (215, '2022-02-16', 161, 2, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (216, '2022-02-16', 162, 1, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (217, '2022-02-17', 66, 5, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (218, '2022-02-17', 163, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (219, '2022-02-17', 164, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (220, '2022-02-17', 165, 6, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (221, '2022-02-17', 166, 3, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (222, '2022-02-18', 167, 12, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (223, '2022-02-18', 168, 11, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (224, '2022-02-18', 169, 10, '', 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `note`, `status`) VALUES (225, '2023-01-14', 170, 500, '', 1);


#
# TABLE STRUCTURE FOR: db_supplier_payments
#

DROP TABLE IF EXISTS `db_supplier_payments`;

CREATE TABLE `db_supplier_payments` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `purchasepayment_id` int(5) DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `payment` double(20,2) DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_date` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `purchasepayment_id` (`purchasepayment_id`),
  CONSTRAINT `db_supplier_payments_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `db_suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `db_supplier_payments_ibfk_2` FOREIGN KEY (`purchasepayment_id`) REFERENCES `db_purchasepayments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: db_suppliers
#

DROP TABLE IF EXISTS `db_suppliers`;

CREATE TABLE `db_suppliers` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gstin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vatin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opening_balance` double(20,2) DEFAULT NULL,
  `purchase_due` double(20,2) DEFAULT NULL,
  `purchase_return_due` double(20,2) DEFAULT NULL,
  `country_id` int(5) DEFAULT NULL,
  `state_id` int(5) DEFAULT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (1, 'SP0001', 'Vento', '', '', '', '', '', NULL, '5000.00', NULL, NULL, 2, 54, '', '', '', '2600:387:f:a10::2', '2600:387:f:a10::2', '2022-02-02', '11:25:27 pm', 'justiniano', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (2, 'SP0002', 'Ricardo Cruz Dist', '', '', '', '', '', NULL, '10000.00', NULL, NULL, 2, NULL, '', '', '', '2600:387:f:a10::2', '2600:387:f:a10::2', '2022-02-02', '11:26:25 pm', 'justiniano', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (3, 'SP0003', 'Correa Tire', '', '', '', '', '', NULL, '0.00', NULL, NULL, 2, NULL, '', '', '', '2600:387:f:a10::2', '2600:387:f:a10::2', '2022-02-02', '11:26:39 pm', 'justiniano', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (4, 'SP0004', 'Centeno Tire', '', '', '', '', '', NULL, '0.00', NULL, NULL, 2, NULL, '', '', '', '2600:387:f:a10::2', '2600:387:f:a10::2', '2022-02-02', '11:26:52 pm', 'justiniano', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (5, 'SP0005', 'Carribean Rubber', '', '', '', '', '', NULL, '0.00', NULL, NULL, 2, NULL, '', '', '', '2600:387:f:a10::2', '2600:387:f:a10::2', '2022-02-02', '11:27:07 pm', 'justiniano', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (6, 'SP0006', 'Burgos tire', '', '', '', '', '', NULL, '0.00', NULL, NULL, 2, NULL, '', '', '', '2600:387:f:a10::2', '2600:387:f:a10::2', '2022-02-02', '11:27:22 pm', 'justiniano', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (7, 'SP0007', 'A Garcia Ferreteria', '', '', '', '', '', NULL, '0.00', NULL, NULL, 2, NULL, '', '', '', '2600:387:f:a10::2', '2600:387:f:a10::2', '2022-02-02', '11:27:47 pm', 'justiniano', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (8, 'SP0008', 'M Group Truper Ferreteria', '', '', '', '', '', NULL, '0.00', NULL, NULL, 3, 54, '', '', '', '2600:387:f:a10::2', '2600:387:f:a10::2', '2022-02-02', '11:28:14 pm', 'justiniano', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (9, 'SP0009', 'Olein Oil', '', '', '', '', '', NULL, '0.00', NULL, NULL, 2, NULL, '', '', '', '2600:387:f:a10::2', '2600:387:f:a10::2', '2022-02-02', '11:28:42 pm', 'justiniano', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (10, 'SP0010', 'Universal Manufaturer', '', '', '', '', '', NULL, '0.00', NULL, NULL, 2, NULL, '', '', '', '2600:387:f:a10::2', '2600:387:f:a10::2', '2022-02-02', '11:29:08 pm', 'justiniano', NULL, 1);


#
# TABLE STRUCTURE FOR: db_tax
#

DROP TABLE IF EXISTS `db_tax`;

CREATE TABLE `db_tax` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax` double(20,2) DEFAULT NULL,
  `group_bit` int(1) DEFAULT NULL COMMENT '1=Yes, 0=No',
  `subtax_ids` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tax groups IDs',
  `status` int(1) DEFAULT NULL,
  `undelete_bit` int(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_tax` (`id`, `tax_name`, `tax`, `group_bit`, `subtax_ids`, `status`, `undelete_bit`) VALUES (1, 'State Tax', '10.50', NULL, NULL, 1, 0);
INSERT INTO `db_tax` (`id`, `tax_name`, `tax`, `group_bit`, `subtax_ids`, `status`, `undelete_bit`) VALUES (2, 'Mun Tax', '1.00', NULL, NULL, 1, 0);
INSERT INTO `db_tax` (`id`, `tax_name`, `tax`, `group_bit`, `subtax_ids`, `status`, `undelete_bit`) VALUES (4, 'IVU', '11.50', 1, '1,2', 1, 0);
INSERT INTO `db_tax` (`id`, `tax_name`, `tax`, `group_bit`, `subtax_ids`, `status`, `undelete_bit`) VALUES (5, 'None', '0.00', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: db_timezone
#

DROP TABLE IF EXISTS `db_timezone`;

CREATE TABLE `db_timezone` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `timezone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=549 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (1, 'Africa/Abidjan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (2, 'Africa/Accra\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (3, 'Africa/Addis_Ababa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (4, 'Africa/Algiers\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (5, 'Africa/Asmara\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (6, 'Africa/Asmera\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (7, 'Africa/Bamako\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (8, 'Africa/Bangui\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (9, 'Africa/Banjul\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (10, 'Africa/Bissau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (11, 'Africa/Blantyre\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (12, 'Africa/Brazzaville\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (13, 'Africa/Bujumbura\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (14, 'Africa/Cairo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (15, 'Africa/Casablanca\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (16, 'Africa/Ceuta\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (17, 'Africa/Conakry\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (18, 'Africa/Dakar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (19, 'Africa/Dar_es_Salaam\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (20, 'Africa/Djibouti\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (21, 'Africa/Douala\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (22, 'Africa/El_Aaiun\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (23, 'Africa/Freetown\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (24, 'Africa/Gaborone\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (25, 'Africa/Harare\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (26, 'Africa/Johannesburg\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (27, 'Africa/Juba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (28, 'Africa/Kampala\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (29, 'Africa/Khartoum\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (30, 'Africa/Kigali\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (31, 'Africa/Kinshasa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (32, 'Africa/Lagos\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (33, 'Africa/Libreville\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (34, 'Africa/Lome\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (35, 'Africa/Luanda\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (36, 'Africa/Lubumbashi\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (37, 'Africa/Lusaka\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (38, 'Africa/Malabo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (39, 'Africa/Maputo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (40, 'Africa/Maseru\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (41, 'Africa/Mbabane\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (42, 'Africa/Mogadishu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (43, 'Africa/Monrovia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (44, 'Africa/Nairobi\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (45, 'Africa/Ndjamena\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (46, 'Africa/Niamey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (47, 'Africa/Nouakchott\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (48, 'Africa/Ouagadougou\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (49, 'Africa/Porto-Novo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (50, 'Africa/Sao_Tome\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (51, 'Africa/Timbuktu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (52, 'Africa/Tripoli\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (53, 'Africa/Tunis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (54, 'Africa/Windhoek\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (55, 'AKST9AKDT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (56, 'America/Adak\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (57, 'America/Anchorage\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (58, 'America/Anguilla\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (59, 'America/Antigua\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (60, 'America/Araguaina\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (61, 'America/Argentina/Buenos_Aires\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (62, 'America/Argentina/Catamarca\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (63, 'America/Argentina/ComodRivadavia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (64, 'America/Argentina/Cordoba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (65, 'America/Argentina/Jujuy\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (66, 'America/Argentina/La_Rioja\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (67, 'America/Argentina/Mendoza\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (68, 'America/Argentina/Rio_Gallegos\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (69, 'America/Argentina/Salta\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (70, 'America/Argentina/San_Juan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (71, 'America/Argentina/San_Luis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (72, 'America/Argentina/Tucuman\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (73, 'America/Argentina/Ushuaia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (74, 'America/Aruba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (75, 'America/Asuncion\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (76, 'America/Atikokan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (77, 'America/Atka\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (78, 'America/Bahia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (79, 'America/Bahia_Banderas\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (80, 'America/Barbados\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (81, 'America/Belem\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (82, 'America/Belize\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (83, 'America/Blanc-Sablon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (84, 'America/Boa_Vista\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (85, 'America/Bogota\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (86, 'America/Boise\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (87, 'America/Buenos_Aires\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (88, 'America/Cambridge_Bay\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (89, 'America/Campo_Grande\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (90, 'America/Cancun\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (91, 'America/Caracas\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (92, 'America/Catamarca\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (93, 'America/Cayenne\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (94, 'America/Cayman\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (95, 'America/Chicago\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (96, 'America/Chihuahua\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (97, 'America/Coral_Harbour\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (98, 'America/Cordoba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (99, 'America/Costa_Rica\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (100, 'America/Creston\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (101, 'America/Cuiaba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (102, 'America/Curacao\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (103, 'America/Danmarkshavn\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (104, 'America/Dawson\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (105, 'America/Dawson_Creek\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (106, 'America/Denver\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (107, 'America/Detroit\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (108, 'America/Dominica\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (109, 'America/Edmonton\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (110, 'America/Eirunepe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (111, 'America/El_Salvador\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (112, 'America/Ensenada\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (113, 'America/Fort_Wayne\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (114, 'America/Fortaleza\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (115, 'America/Glace_Bay\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (116, 'America/Godthab\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (117, 'America/Goose_Bay\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (118, 'America/Grand_Turk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (119, 'America/Grenada\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (120, 'America/Guadeloupe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (121, 'America/Guatemala\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (122, 'America/Guayaquil\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (123, 'America/Guyana\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (124, 'America/Halifax\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (125, 'America/Havana\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (126, 'America/Hermosillo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (127, 'America/Indiana/Indianapolis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (128, 'America/Indiana/Knox\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (129, 'America/Indiana/Marengo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (130, 'America/Indiana/Petersburg\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (131, 'America/Indiana/Tell_City\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (132, 'America/Indiana/Vevay\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (133, 'America/Indiana/Vincennes\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (134, 'America/Indiana/Winamac\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (135, 'America/Indianapolis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (136, 'America/Inuvik\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (137, 'America/Iqaluit\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (138, 'America/Jamaica\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (139, 'America/Jujuy\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (140, 'America/Juneau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (141, 'America/Kentucky/Louisville\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (142, 'America/Kentucky/Monticello\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (143, 'America/Knox_IN\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (144, 'America/Kralendijk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (145, 'America/La_Paz\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (146, 'America/Lima\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (147, 'America/Los_Angeles\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (148, 'America/Louisville\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (149, 'America/Lower_Princes\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (150, 'America/Maceio\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (151, 'America/Managua\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (152, 'America/Manaus\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (153, 'America/Marigot\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (154, 'America/Martinique\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (155, 'America/Matamoros\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (156, 'America/Mazatlan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (157, 'America/Mendoza\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (158, 'America/Menominee\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (159, 'America/Merida\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (160, 'America/Metlakatla\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (161, 'America/Mexico_City\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (162, 'America/Miquelon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (163, 'America/Moncton\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (164, 'America/Monterrey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (165, 'America/Montevideo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (166, 'America/Montreal\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (167, 'America/Montserrat\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (168, 'America/Nassau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (169, 'America/New_York\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (170, 'America/Nipigon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (171, 'America/Nome\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (172, 'America/Noronha\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (173, 'America/North_Dakota/Beulah\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (174, 'America/North_Dakota/Center\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (175, 'America/North_Dakota/New_Salem\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (176, 'America/Ojinaga\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (177, 'America/Panama\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (178, 'America/Pangnirtung\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (179, 'America/Paramaribo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (180, 'America/Phoenix\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (181, 'America/Port_of_Spain\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (182, 'America/Port-au-Prince\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (183, 'America/Porto_Acre\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (184, 'America/Porto_Velho\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (185, 'America/Puerto_Rico\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (186, 'America/Rainy_River\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (187, 'America/Rankin_Inlet\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (188, 'America/Recife\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (189, 'America/Regina\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (190, 'America/Resolute\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (191, 'America/Rio_Branco\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (192, 'America/Rosario\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (193, 'America/Santa_Isabel\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (194, 'America/Santarem\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (195, 'America/Santiago\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (196, 'America/Santo_Domingo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (197, 'America/Sao_Paulo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (198, 'America/Scoresbysund\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (199, 'America/Shiprock\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (200, 'America/Sitka\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (201, 'America/St_Barthelemy\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (202, 'America/St_Johns\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (203, 'America/St_Kitts\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (204, 'America/St_Lucia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (205, 'America/St_Thomas\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (206, 'America/St_Vincent\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (207, 'America/Swift_Current\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (208, 'America/Tegucigalpa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (209, 'America/Thule\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (210, 'America/Thunder_Bay\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (211, 'America/Tijuana\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (212, 'America/Toronto\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (213, 'America/Tortola\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (214, 'America/Vancouver\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (215, 'America/Virgin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (216, 'America/Whitehorse\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (217, 'America/Winnipeg\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (218, 'America/Yakutat\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (219, 'America/Yellowknife\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (220, 'Antarctica/Casey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (221, 'Antarctica/Davis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (222, 'Antarctica/DumontDUrville\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (223, 'Antarctica/Macquarie\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (224, 'Antarctica/Mawson\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (225, 'Antarctica/McMurdo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (226, 'Antarctica/Palmer\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (227, 'Antarctica/Rothera\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (228, 'Antarctica/South_Pole\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (229, 'Antarctica/Syowa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (230, 'Antarctica/Vostok\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (231, 'Arctic/Longyearbyen\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (232, 'Asia/Aden\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (233, 'Asia/Almaty\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (234, 'Asia/Amman\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (235, 'Asia/Anadyr\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (236, 'Asia/Aqtau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (237, 'Asia/Aqtobe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (238, 'Asia/Ashgabat\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (239, 'Asia/Ashkhabad\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (240, 'Asia/Baghdad\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (241, 'Asia/Bahrain\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (242, 'Asia/Baku\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (243, 'Asia/Bangkok\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (244, 'Asia/Beirut\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (245, 'Asia/Bishkek\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (246, 'Asia/Brunei\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (247, 'Asia/Calcutta\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (248, 'Asia/Choibalsan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (249, 'Asia/Chongqing\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (250, 'Asia/Chungking\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (251, 'Asia/Colombo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (252, 'Asia/Dacca\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (253, 'Asia/Damascus\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (254, 'Asia/Dhaka\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (255, 'Asia/Dili\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (256, 'Asia/Dubai\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (257, 'Asia/Dushanbe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (258, 'Asia/Gaza\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (259, 'Asia/Harbin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (260, 'Asia/Hebron\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (261, 'Asia/Ho_Chi_Minh\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (262, 'Asia/Hong_Kong\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (263, 'Asia/Hovd\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (264, 'Asia/Irkutsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (265, 'Asia/Istanbul\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (266, 'Asia/Jakarta\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (267, 'Asia/Jayapura\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (268, 'Asia/Jerusalem\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (269, 'Asia/Kabul\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (270, 'Asia/Kamchatka\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (271, 'Asia/Karachi\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (272, 'Asia/Kashgar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (273, 'Asia/Kathmandu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (274, 'Asia/Katmandu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (275, 'Asia/Kolkata\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (276, 'Asia/Krasnoyarsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (277, 'Asia/Kuala_Lumpur\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (278, 'Asia/Kuching\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (279, 'Asia/Kuwait\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (280, 'Asia/Macao\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (281, 'Asia/Macau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (282, 'Asia/Magadan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (283, 'Asia/Makassar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (284, 'Asia/Manila\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (285, 'Asia/Muscat\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (286, 'Asia/Nicosia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (287, 'Asia/Novokuznetsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (288, 'Asia/Novosibirsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (289, 'Asia/Omsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (290, 'Asia/Oral\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (291, 'Asia/Phnom_Penh\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (292, 'Asia/Pontianak\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (293, 'Asia/Pyongyang\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (294, 'Asia/Qatar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (295, 'Asia/Qyzylorda\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (296, 'Asia/Rangoon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (297, 'Asia/Riyadh\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (298, 'Asia/Saigon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (299, 'Asia/Sakhalin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (300, 'Asia/Samarkand\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (301, 'Asia/Seoul\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (302, 'Asia/Shanghai\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (303, 'Asia/Singapore\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (304, 'Asia/Taipei\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (305, 'Asia/Tashkent\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (306, 'Asia/Tbilisi\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (307, 'Asia/Tehran\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (308, 'Asia/Tel_Aviv\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (309, 'Asia/Thimbu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (310, 'Asia/Thimphu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (311, 'Asia/Tokyo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (312, 'Asia/Ujung_Pandang\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (313, 'Asia/Ulaanbaatar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (314, 'Asia/Ulan_Bator\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (315, 'Asia/Urumqi\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (316, 'Asia/Vientiane\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (317, 'Asia/Vladivostok\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (318, 'Asia/Yakutsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (319, 'Asia/Yekaterinburg\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (320, 'Asia/Yerevan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (321, 'Atlantic/Azores\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (322, 'Atlantic/Bermuda\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (323, 'Atlantic/Canary\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (324, 'Atlantic/Cape_Verde\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (325, 'Atlantic/Faeroe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (326, 'Atlantic/Faroe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (327, 'Atlantic/Jan_Mayen\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (328, 'Atlantic/Madeira\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (329, 'Atlantic/Reykjavik\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (330, 'Atlantic/South_Georgia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (331, 'Atlantic/St_Helena\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (332, 'Atlantic/Stanley\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (333, 'Australia/ACT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (334, 'Australia/Adelaide\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (335, 'Australia/Brisbane\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (336, 'Australia/Broken_Hill\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (337, 'Australia/Canberra\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (338, 'Australia/Currie\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (339, 'Australia/Darwin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (340, 'Australia/Eucla\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (341, 'Australia/Hobart\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (342, 'Australia/LHI\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (343, 'Australia/Lindeman\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (344, 'Australia/Lord_Howe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (345, 'Australia/Melbourne\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (346, 'Australia/North\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (347, 'Australia/NSW\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (348, 'Australia/Perth\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (349, 'Australia/Queensland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (350, 'Australia/South\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (351, 'Australia/Sydney\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (352, 'Australia/Tasmania\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (353, 'Australia/Victoria\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (354, 'Australia/West\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (355, 'Australia/Yancowinna\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (356, 'Brazil/Acre\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (357, 'Brazil/DeNoronha\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (358, 'Brazil/East\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (359, 'Brazil/West\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (360, 'Canada/Atlantic\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (361, 'Canada/Central\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (362, 'Canada/Eastern\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (363, 'Canada/East-Saskatchewan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (364, 'Canada/Mountain\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (365, 'Canada/Newfoundland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (366, 'Canada/Pacific\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (367, 'Canada/Saskatchewan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (368, 'Canada/Yukon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (369, 'CET\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (370, 'Chile/Continental\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (371, 'Chile/EasterIsland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (372, 'CST6CDT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (373, 'Cuba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (374, 'EET\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (375, 'Egypt\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (376, 'Eire\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (377, 'EST\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (378, 'EST5EDT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (379, 'Etc./GMT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (380, 'Etc./GMT+0\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (381, 'Etc./UCT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (382, 'Etc./Universal\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (383, 'Etc./UTC\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (384, 'Etc./Zulu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (385, 'Europe/Amsterdam\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (386, 'Europe/Andorra\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (387, 'Europe/Athens\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (388, 'Europe/Belfast\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (389, 'Europe/Belgrade\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (390, 'Europe/Berlin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (391, 'Europe/Bratislava\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (392, 'Europe/Brussels\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (393, 'Europe/Bucharest\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (394, 'Europe/Budapest\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (395, 'Europe/Chisinau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (396, 'Europe/Copenhagen\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (397, 'Europe/Dublin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (398, 'Europe/Gibraltar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (399, 'Europe/Guernsey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (400, 'Europe/Helsinki\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (401, 'Europe/Isle_of_Man\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (402, 'Europe/Istanbul\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (403, 'Europe/Jersey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (404, 'Europe/Kaliningrad\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (405, 'Europe/Kiev\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (406, 'Europe/Lisbon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (407, 'Europe/Ljubljana\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (408, 'Europe/London\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (409, 'Europe/Luxembourg\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (410, 'Europe/Madrid\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (411, 'Europe/Malta\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (412, 'Europe/Mariehamn\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (413, 'Europe/Minsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (414, 'Europe/Monaco\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (415, 'Europe/Moscow\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (416, 'Europe/Nicosia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (417, 'Europe/Oslo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (418, 'Europe/Paris\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (419, 'Europe/Podgorica\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (420, 'Europe/Prague\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (421, 'Europe/Riga\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (422, 'Europe/Rome\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (423, 'Europe/Samara\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (424, 'Europe/San_Marino\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (425, 'Europe/Sarajevo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (426, 'Europe/Simferopol\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (427, 'Europe/Skopje\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (428, 'Europe/Sofia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (429, 'Europe/Stockholm\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (430, 'Europe/Tallinn\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (431, 'Europe/Tirane\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (432, 'Europe/Tiraspol\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (433, 'Europe/Uzhgorod\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (434, 'Europe/Vaduz\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (435, 'Europe/Vatican\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (436, 'Europe/Vienna\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (437, 'Europe/Vilnius\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (438, 'Europe/Volgograd\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (439, 'Europe/Warsaw\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (440, 'Europe/Zagreb\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (441, 'Europe/Zaporozhye\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (442, 'Europe/Zurich\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (443, 'GB\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (444, 'GB-Eire\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (445, 'GMT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (446, 'GMT+0\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (447, 'GMT0\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (448, 'GMT-0\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (449, 'Greenwich\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (450, 'Hong Kong\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (451, 'HST\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (452, 'Iceland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (453, 'Indian/Antananarivo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (454, 'Indian/Chagos\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (455, 'Indian/Christmas\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (456, 'Indian/Cocos\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (457, 'Indian/Comoro\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (458, 'Indian/Kerguelen\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (459, 'Indian/Mahe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (460, 'Indian/Maldives\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (461, 'Indian/Mauritius\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (462, 'Indian/Mayotte\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (463, 'Indian/Reunion\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (464, 'Iran\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (465, 'Israel\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (466, 'Jamaica\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (467, 'Japan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (468, 'JST-9\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (469, 'Kwajalein\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (470, 'Libya\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (471, 'MET\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (472, 'Mexico/BajaNorte\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (473, 'Mexico/BajaSur\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (474, 'Mexico/General\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (475, 'MST\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (476, 'MST7MDT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (477, 'Navajo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (478, 'NZ\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (479, 'NZ-CHAT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (480, 'Pacific/Apia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (481, 'Pacific/Auckland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (482, 'Pacific/Chatham\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (483, 'Pacific/Chuuk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (484, 'Pacific/Easter\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (485, 'Pacific/Efate\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (486, 'Pacific/Enderbury\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (487, 'Pacific/Fakaofo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (488, 'Pacific/Fiji\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (489, 'Pacific/Funafuti\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (490, 'Pacific/Galapagos\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (491, 'Pacific/Gambier\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (492, 'Pacific/Guadalcanal\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (493, 'Pacific/Guam\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (494, 'Pacific/Honolulu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (495, 'Pacific/Johnston\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (496, 'Pacific/Kiritimati\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (497, 'Pacific/Kosrae\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (498, 'Pacific/Kwajalein\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (499, 'Pacific/Majuro\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (500, 'Pacific/Marquesas\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (501, 'Pacific/Midway\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (502, 'Pacific/Nauru\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (503, 'Pacific/Niue\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (504, 'Pacific/Norfolk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (505, 'Pacific/Noumea\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (506, 'Pacific/Pago_Pago\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (507, 'Pacific/Palau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (508, 'Pacific/Pitcairn\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (509, 'Pacific/Pohnpei\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (510, 'Pacific/Ponape\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (511, 'Pacific/Port_Moresby\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (512, 'Pacific/Rarotonga\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (513, 'Pacific/Saipan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (514, 'Pacific/Samoa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (515, 'Pacific/Tahiti\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (516, 'Pacific/Tarawa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (517, 'Pacific/Tongatapu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (518, 'Pacific/Truk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (519, 'Pacific/Wake\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (520, 'Pacific/Wallis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (521, 'Pacific/Yap\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (522, 'Poland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (523, 'Portugal\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (524, 'PRC\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (525, 'PST8PDT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (526, 'ROC\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (527, 'ROK\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (528, 'Singapore\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (529, 'Turkey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (530, 'UCT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (531, 'Universal\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (532, 'US/Alaska\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (533, 'US/Aleutian\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (534, 'US/Arizona\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (535, 'US/Central\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (536, 'US/Eastern\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (537, 'US/East-Indiana\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (538, 'US/Hawaii\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (539, 'US/Indiana-Starke\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (540, 'US/Michigan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (541, 'US/Mountain\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (542, 'US/Pacific\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (543, 'US/Pacific-New\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (544, 'US/Samoa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (545, 'UTC\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (546, 'WET\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (547, 'W-SU\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (548, 'Zulu\r', 1);


#
# TABLE STRUCTURE FOR: db_units
#

DROP TABLE IF EXISTS `db_units`;

CREATE TABLE `db_units` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (16, 'N/A', '', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (17, 'Unit', '', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (18, 'LB', 'Pound', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (19, 'pies', '', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (20, 'paquete', 'venta por apquete', NULL, 1);


#
# TABLE STRUCTURE FOR: db_users
#

DROP TABLE IF EXISTS `db_users`;

CREATE TABLE `db_users` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `username` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` blob DEFAULT NULL,
  `member_of` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstname` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(405) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` blob DEFAULT NULL,
  `gender` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `country` varchar(1620) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(1620) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` blob DEFAULT NULL,
  `postcode` varchar(270) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_name` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int(5) DEFAULT NULL,
  `profile_picture` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_users` (`id`, `username`, `password`, `member_of`, `firstname`, `lastname`, `mobile`, `email`, `photo`, `gender`, `dob`, `country`, `state`, `city`, `address`, `postcode`, `role_name`, `role_id`, `profile_picture`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`) VALUES (1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '', NULL, NULL, '573504931577', 'admin@latamcodev.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '', '2018-11-27', '::1', NULL, NULL, NULL, 1, '1');
INSERT INTO `db_users` (`id`, `username`, `password`, `member_of`, `firstname`, `lastname`, `mobile`, `email`, `photo`, `gender`, `dob`, `country`, `state`, `city`, `address`, `postcode`, `role_name`, `role_id`, `profile_picture`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`) VALUES (2, 'david', '01cfcd4f6b8770febfb40cb906715822', NULL, NULL, NULL, '1234567', 'david@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, '', '2022-11-21', '05:52:21 pm', 'admin', '189.215.144.136', '189.215.144.136.cable.dyn.cableonline.com.mx', NULL, '1');


#
# TABLE STRUCTURE FOR: db_warehouse
#

DROP TABLE IF EXISTS `db_warehouse`;

CREATE TABLE `db_warehouse` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `warehouse_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET foreign_key_checks = 1;
